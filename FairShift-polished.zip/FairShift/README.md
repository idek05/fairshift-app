# FairShift — Decent Work Platform

A zero-dependency Node.js demo for Prompt Wars 2026 / UN SDG 8. It demonstrates worker shift tracking, itemised payslips, anonymous workplace reports, skill passports, and employer workforce insights across construction and college profiles.

## Run locally (Node.js 20+)

```powershell
npm test
npm start
```

Open http://localhost:8080. Demo mode is enabled by default. The demo data is in memory and resets when the server restarts; this is a hackathon prototype, not production payroll software.

## Deploy to Google Cloud Run

The included `Dockerfile` listens on the Cloud Run-provided `PORT`. In Google Cloud Console, select a project with billing enabled, open Cloud Run, choose **Deploy container / from source** (wording may vary), connect or upload this project from a public GitHub repository, and deploy. Set `DEMO_MODE=true` for the demo. For a non-demo deployment, configure a strong `FAIRSHIFT_SECRET`, set an `ADMIN_PASSCODE`, and set `DEMO_MODE=false`.

## Important prototype limitations

- Demo records are in-memory and are not durable across restarts.
- Do not enter real employee/payroll data.
- The included site QR codes encode the demo site code used by the attendance check-in flow. Camera-based scanning depends on browser support for BarcodeDetector and camera permission; manual site-code entry remains available as a fallback.
- The compact `i18n.js` fallback supports language selection and locale formatting, but not every screen string has been translated.
- Verify all user journeys and Cloud Run URL before submitting.
