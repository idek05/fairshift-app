const LANG_KEY = 'fs.lang';
const supported = ['en', 'ta', 'hi'];
export const getLang = () => { try { const v = localStorage.getItem(LANG_KEY); return supported.includes(v) ? v : 'en'; } catch { return 'en'; } };
export const setLang = (v) => { if (supported.includes(v)) { try { localStorage.setItem(LANG_KEY, v); } catch {} } };
export const locale = () => ({ en: 'en-IN', ta: 'ta-IN', hi: 'hi-IN' }[getLang()] || 'en-IN');
export const t = (key, vars = {}) => {
  const words = {
    'common.loading':'Loading…','common.retry':'Try again','common.error':'Something went wrong',
    'pay.col.date':'Date','pay.col.time':'Shift time','pay.col.hours':'Hours worked','pay.col.ot':'Overtime',
    'pay.dispute':'Report a pay issue','pay.dispute.text':'I would like to query my recorded hours or pay for {date}.',
    'pay.title':'Your payslip','pay.worked':'{days} days worked · {hours} total hours','pay.gross':'Gross pay','pay.net':'Take-home pay','pay.days':'Attendance history','pay.days.help':'Review each recorded shift and report any mismatch.','pay.empty':'No recorded shifts for this month yet.','pay.inprogress':'This payslip is still in progress.','pay.listen':'Read payslip aloud','pay.autoclosed':'Auto-closed shift',
    'today.greeting':'Hello, {name}','today.checkin':'Check in','today.checkout':'Check out','today.notonshift':'You are not currently clocked in.','today.onshift':'Checked in at {time}','today.clock':'Shift attendance','today.method.qr':'Scan workplace QR','today.method.geo':'Verify work location','today.method.type':'Enter site code instead','today.method.code':'Workplace site code','today.demo':'Demo mode','today.demo.qr':'Use demo attendance','today.qr.unsupported':'QR scanning is not supported in this browser. Enter the site code instead.','today.qr.denied':'Camera access was unavailable. Enter the site code instead.',
    'status.submitted':'Submitted','status.in_review':'In review','status.resolved':'Resolved','status.open':'Open',
    'nav.today':'Today','nav.pay':'Pay','nav.speak':'Speak up','nav.passport':'Passport',
    'today.week':'This week','today.std':'Standard: {hours} hours',
    'pp.share.copied':'Link copied','pp.share.copyfail':'Copy the link manually',
  };
  const fallback = key.split('.').slice(-1)[0].replace(/([A-Z])/g, ' $1').replace(/[_-]/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  return (words[key] || fallback).replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? `{${k}}`));
};
export function initLanguageSelect(el, onChange) { if (!el) return; el.value = getLang(); el.addEventListener('change', () => { setLang(el.value); onChange?.(); }); }
export function applyI18n(root) { if (!root) return; root.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); }); }
