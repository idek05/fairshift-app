import { session } from './common.js';
const $ = id => document.getElementById(id);
let industries = [];
async function request(path, options={}) { const r=await fetch(path,{...options,headers:{'Content-Type':'application/json',...(options.headers||{})}}); const d=await r.json(); if(!r.ok) throw new Error(d.message||d.error||'Request failed'); return d; }
function say(msg){$('message').textContent=msg;}
async function load(){ try { const d=await request('/api/industries'); industries=d.industries; $('industry').innerHTML=industries.map(x=>`<option value="${x.id}">${x.label || (x.id === 'college' ? 'University / College campus' : x.id === 'construction' ? 'Construction site' : x.id)}</option>`).join(''); await loadWorkers(); } catch(e){say('Could not connect to the demo API: '+e.message)} }
async function loadWorkers(){try{const d=await request('/api/demo-workers?industry='+encodeURIComponent($('industry').value));$('worker-picker').innerHTML=d.workers.map(w=>`<option value="${w.id}">${w.name} — ${w.role}</option>`).join('');}catch(e){say(e.message)}}
$('industry').addEventListener('change',loadWorkers);
$('worker-login').addEventListener('click',async()=>{try{const d=await request('/api/session',{method:'POST',body:JSON.stringify({role:'worker',industry:$('industry').value,workerId:$('worker-picker').value})});session.set({token:d.token,role:d.role,industry:d.industry,worker:d.worker});location.href='/worker.html';}catch(e){say(e.message)}});
$('admin-login').addEventListener('click',async()=>{try{const d=await request('/api/session',{method:'POST',body:JSON.stringify({role:'admin',industry:$('industry').value,passcode:$('passcode').value})});session.set({token:d.token,role:d.role,industry:d.industry});location.href='/admin.html';}catch(e){say(e.message)}});
$('worker-login').addEventListener('click',()=>{$('worker-picker-wrap').hidden=false;});
$('admin-login').addEventListener('focus',()=>{$('passcode-wrap').hidden=false;});
load();
