// Worker interface: Today (check-in), Pay, Speak up (reports + anonymous feedback), Passport.
import {
  api, html, render, icon, session, toast, errorMessage, fmt, currentMonth, shiftMonth, bar,
} from './common.js';
import { t, getLang, setLang, initLanguageSelect, applyI18n } from './i18n.js';
import {
  canDictate, startDictation, canSpeak, speak, canScanQr, startQrScan, getPosition,
} from './device.js';

const CATEGORIES = ['safety', 'pay', 'conduct', 'schedule', 'facilities', 'other'];
const FEEDBACK_QUESTIONS = ['manager', 'safety', 'pay', 'workplace'];
const TABS = [['today', 'clock', 'nav.today'], ['pay', 'receipt', 'nav.pay'], ['speak', 'speak', 'nav.speak'], ['passport', 'passport', 'nav.passport']];
const CODES_KEY = 'fs.anonCodes';

const view = document.getElementById('view');
const state = {
  me: null,
  tab: 'today',
  month: currentMonth(),
  speakTab: 'report',
  draft: { category: 'safety', zone: 'other', text: '', anonymous: false },
  lastReport: null,
  feedbackDone: false,
  checkinOpen: false,
  addOpen: false,
  addKind: 'certification',
  today: null,
  payslip: null,
  ticker: null,
  stopDictation: null,
  stopScan: null,
};

const savedCodes = () => { try { return JSON.parse(localStorage.getItem(CODES_KEY)) || []; } catch { return []; } };
const saveCode = (code) => localStorage.setItem(CODES_KEY, JSON.stringify([...new Set([code, ...savedCodes()])].slice(0, 20)));

/* ------------------------------------------------------------------ */
/* shell                                                               */
/* ------------------------------------------------------------------ */

function renderChrome() {
  document.getElementById('who').textContent = state.me.worker.name;
  render(document.getElementById('tabs'), html`${TABS.map(([id, ic, key]) => html`
    <a class="tab" href="#${id}" ${id === state.tab ? html`aria-current="page"` : ''}>${icon(ic)}<span>${t(key)}</span></a>`)}`);
  applyI18n(document);
}

async function show(tab = state.tab) {
  state.tab = tab;
  clearInterval(state.ticker);
  state.stopDictation?.();
  renderChrome();
  render(view, html`<p class="loading">${t('common.loading')}</p>`);
  try {
    await ({ today: viewToday, pay: viewPay, speak: viewSpeak, passport: viewPassport }[tab])();
  } catch (err) {
    render(view, html`<div class="panel"><p>${errorMessage(err)}</p><button class="btn" data-action="reload">${t('common.retry')}</button></div>`);
  }
  window.scrollTo(0, 0);
}

/* ------------------------------------------------------------------ */
/* Today                                                               */
/* ------------------------------------------------------------------ */

const clockText = (ms) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  return [Math.floor(s / 3600), Math.floor(s / 60) % 60, s % 60].map((n) => String(n).padStart(2, '0')).join(':');
};

function weekChart(days) {
  const MAX = 14;
  const base = 100;
  const scale = 90 / MAX;
  const stdY = base - 8 * scale;
  return html`<svg class="week" viewBox="0 0 280 128" role="img" aria-label="${t('today.week')}: ${days.map((d) => `${fmt.dateKey(d.date)} ${fmt.num(d.hours)} h`).join(', ')}">
    <line class="week__std" x1="4" x2="276" y1="${stdY}" y2="${stdY}"/>
    <text x="276" y="${stdY - 4}" text-anchor="end">${t('today.std', { hours: 8 })}</text>
    ${days.map((d, i) => {
    const h = Math.min(MAX, d.hours) * scale;
    const x = 10 + i * 38;
    const tone = d.hours > 10 ? 'alert' : d.hours > 8 ? 'warn' : '';
    return html`<rect class="week__bar ${tone ? `week__bar--${tone}` : ''}" x="${x}" y="${base - h}" width="26" height="${h}" rx="3"/>
      ${d.hours > 0 ? html`<text class="week__val" x="${x + 13}" y="${base - h - 4}" text-anchor="middle">${fmt.num(d.hours)}</text>` : ''}
      <text x="${x + 13}" y="118" text-anchor="middle">${fmt.weekday(d.date)}</text>`;
  })}
  </svg>`;
}

function restPanel(today) {
  const f = today.fatigue;
  const tone = f.level === 'high' ? 'alert' : f.level === 'warn' ? 'warn' : 'ok';
  const reasons = f.reasons.map((r) => html`<li>${t(`fatigue.${r.code}`, r)}</li>`);
  return html`<section class="panel" aria-labelledby="rest-h">
    <div class="panel__head"><h2 id="rest-h">${t('today.week')}</h2><strong class="num">${fmt.num(f.weeklyHours)} / ${today.weeklyLimit} h</strong></div>
    ${bar(f.weeklyHours, today.weeklyLimit, tone, t('today.week'))}
    <div class="callout callout--${tone}" role="${f.level === 'ok' ? 'status' : 'alert'}">
      ${f.level === 'ok'
    ? html`<p><strong>${icon('check')} ${t('today.rest.ok')}</strong></p>`
    : html`<p><strong>${icon('alert')} ${t(`today.rest.${f.level}`)}</strong></p><ul>${reasons}</ul>
         <p class="small">${t('today.rest.help')}</p>
         <button class="btn btn--sm" data-action="report-fatigue">${t('today.rest.report')}</button>`}
    </div>
    ${weekChart(today.week)}
  </section>`;
}

async function viewToday() {
  const today = await api('/api/me/today');
  state.today = today;
  const { openShift } = today;
  const { demoSiteCode } = state.me;

  render(view, html`
    <div class="greeting"><h1>${t('today.greeting', { name: state.me.worker.name })}</h1>
      <p class="muted">${state.me.industry.employer} · ${state.me.industry.siteName}</p></div>
    <section class="panel clock" aria-labelledby="clock-h">
      <h2 class="sr-only" id="clock-h">${t('today.clock')}</h2>
      ${openShift
    ? html`<button class="punch punch--on" data-action="checkout"><span class="punch__time" id="elapsed">${clockText(Date.now() - Date.parse(openShift.checkIn))}</span><span>${t('today.checkout')}</span></button>
         <p class="clock__status">${t('today.onshift', { time: fmt.time(openShift.checkIn) })}</p>`
    : html`<button class="punch" data-action="checkin-toggle" aria-expanded="${state.checkinOpen}"><span>${icon('clock')}</span><span>${t('today.checkin')}</span></button>
         <p class="clock__status">${t('today.notonshift')}</p>`}
      ${!openShift && state.checkinOpen ? html`
        <div class="methods">
          <div class="clock__methods">
            <button class="btn" data-action="scan">${icon('scan')} ${t('today.method.qr')}</button>
            <button class="btn" data-action="geo">${icon('pin')} ${t('today.method.geo')}</button>
          </div>
          <details class="method-help"><summary>${t('today.method.type')}</summary>
            <form class="row" data-form="code"><label class="grow"><span class="sr-only">${t('today.method.code')}</span>
              <input type="text" id="site-code" autocomplete="off" autocapitalize="characters" placeholder="${t('today.method.code')}"></label>
              <button class="btn btn--primary" type="submit">${t('today.checkin')}</button></form>
          </details>
          ${demoSiteCode ? html`<div class="demo-note"><strong>${t('today.demo')}</strong>
            <div class="row"><button class="btn btn--quiet btn--sm" data-action="demo-qr">${t('today.demo.qr')}</button>
            <button class="btn btn--quiet btn--sm" data-action="demo-geo">${t('today.demo.geo')}</button></div></div>` : ''}
        </div>` : ''}
    </section>
    ${restPanel(today)}
    <dialog id="scan-dialog" aria-labelledby="scan-h"><h2 id="scan-h">${t('today.method.qr')}</h2>
      <video id="scan-video" playsinline muted></video>
      <p class="small muted">${t('today.scan.help')}</p>
      <button class="btn btn--block" data-action="scan-close">${t('common.cancel')}</button></dialog>`);

  if (openShift) {
    const started = Date.parse(openShift.checkIn);
    state.ticker = setInterval(() => {
      const el = document.getElementById('elapsed');
      if (el) el.textContent = clockText(Date.now() - started);
    }, 1000);
  }
}

async function submitCheckIn(body) {
  try {
    await api('/api/me/check-in', { method: 'POST', body });
    state.checkinOpen = false;
    toast(t('today.checkedin.ok'), 'ok');
    await show('today');
  } catch (err) {
    toast(errorMessage(err), 'error');
  }
}

async function checkOut() {
  try {
    const { shift } = await api('/api/me/check-out', { method: 'POST' });
    const extra = shift.overtime > 0 ? ` ${t('today.checkedout.ot', { ot: fmt.num(shift.overtime) })}` : '';
    toast(t('today.checkedout.ok', { hours: fmt.num(shift.hours) }) + extra, 'ok');
    await show('today');
  } catch (err) {
    toast(errorMessage(err), 'error');
  }
}

async function useLocation(demo) {
  try {
    const pos = demo
      ? { lat: state.me.industry.site.lat, lng: state.me.industry.site.lng }
      : await getPosition();
    await submitCheckIn({ method: 'geo', ...pos });
  } catch (err) {
    toast(err.code === undefined || err.status ? errorMessage(err) : t('today.geo.denied'), 'error');
  }
}

async function openScanner() {
  const dialog = document.getElementById('scan-dialog');
  if (!canScanQr) {
    toast(t('today.qr.unsupported'));
    view.querySelector('.method-help')?.setAttribute('open', '');
    return;
  }
  try {
    dialog.showModal();
    state.stopScan = await startQrScan(document.getElementById('scan-video'), (code) => {
      closeScanner();
      submitCheckIn({ method: 'qr', code });
    });
  } catch {
    closeScanner();
    toast(t('today.qr.denied'), 'error');
  }
}

function closeScanner() {
  state.stopScan?.();
  state.stopScan = null;
  const dialog = document.getElementById('scan-dialog');
  if (dialog?.open) dialog.close();
}

/* ------------------------------------------------------------------ */
/* Pay                                                                 */
/* ------------------------------------------------------------------ */

function receiptLine({ name, amount, why, minus = false }) {
  return html`<div class="line ${minus ? 'line--minus' : ''}"><span class="line__name">${name}</span><span class="line__dots" aria-hidden="true"></span>
    <span class="line__amt num">${minus ? '−' : ''}${fmt.money(amount)}</span></div>${why ? html`<p class="line__why">${why}</p>` : ''}`;
}

async function viewPay() {
  const p = await api(`/api/me/payslip?month=${state.month}`);
  state.payslip = p;
  const monthLabel = fmt.month(p.month);

  const earnings = p.earnings.map((e) => receiptLine({
    name: t(`pay.${e.code}`),
    amount: e.amount,
    why: e.code === 'regular'
      ? t('pay.regular.why', { hours: fmt.num(e.hours, 2), rate: fmt.money(e.rate) })
      : t('pay.overtime.why', { hours: fmt.num(e.hours, 2), rate: fmt.money(e.rate), multiplier: e.multiplier, std: p.rules.standardDailyHours }),
  }));
  const deductions = p.deductions.map((d) => receiptLine({
    name: t(`pay.${d.code}`), amount: d.amount, minus: true,
    why: t(`pay.${d.code}.why`, { rate: fmt.num((d.rate || 0) * 100, 2) }),
  }));

  render(view, html`
    <div class="month-nav">
      <button class="btn btn--sm btn--quiet" data-action="month-prev" aria-label="${t('pay.prev')}">${icon('chevronLeft')}</button>
      <strong>${monthLabel}</strong>
      <button class="btn btn--sm btn--quiet" data-action="month-next" aria-label="${t('pay.next')}" ${p.month >= currentMonth() ? 'disabled' : ''}>${icon('chevronRight')}</button>
    </div>
    ${p.totals.daysWorked === 0 ? html`<div class="empty">${t('pay.empty')}</div>` : html`
    <article class="receipt" aria-labelledby="pay-h">
      <h2 id="pay-h">${t('pay.title')}</h2>
      <p class="muted small">${t('pay.worked', { days: p.totals.daysWorked, hours: fmt.num(p.totals.totalHours) })}</p>
      ${earnings}
      ${receiptLine({ name: t('pay.gross'), amount: p.gross })}
      <hr class="rule">
      ${deductions}
      <hr class="rule">
      <div class="line line--total"><span class="line__name">${t('pay.net')}</span><span class="line__dots" aria-hidden="true"></span><span class="line__amt num">${fmt.money(p.net)}</span></div>
    </article>
    ${p.inProgress ? html`<p class="callout">${t('pay.inprogress')}</p>` : ''}
    <div class="row no-print">${canSpeak ? html`<button class="btn" data-action="listen">${icon('volume')} ${t('pay.listen')}</button>` : ''}</div>
    <section class="panel" aria-labelledby="days-h"><h2 id="days-h">${t('pay.days')}</h2>
      <p class="muted small">${t('pay.days.help')}</p>
      <table class="daylist"><thead><tr><th scope="col">${t('pay.col.date')}</th><th scope="col">${t('pay.col.time')}</th><th scope="col" class="r">${t('pay.col.hours')}</th><th scope="col" class="r">${t('pay.col.ot')}</th></tr></thead>
      <tbody>${[...p.days].reverse().map((d) => html`<tr>
        <td><strong>${fmt.dateKey(d.date)}</strong><br><button class="tbtn small" data-action="dispute" data-date="${d.date}">${t('pay.dispute')}</button></td>
        <td>${fmt.time(d.checkIn)}–${fmt.time(d.checkOut)}${d.autoClosed ? html`<br><span class="badge badge--warn">${t('pay.autoclosed')}</span>` : ''}</td>
        <td class="r num">${fmt.num(d.hours)}</td>
        <td class="r num">${d.overtime > 0 ? html`<span class="badge badge--info">+${fmt.num(d.overtime)}</span>` : '–'}</td></tr>`)}</tbody></table>
    </section>`}`);
}

/* ------------------------------------------------------------------ */
/* Speak up                                                            */
/* ------------------------------------------------------------------ */

const statusBadge = (s) => html`<span class="badge ${s === 'resolved' ? 'badge--ok' : s === 'in_review' ? 'badge--info' : ''}">${t(`status.${s}`)}</span>`;

function reportForm() {
  const d = state.draft;
  const zones = state.me.industry.zones;
  return html`<form data-form="report" novalidate>
    <fieldset class="chips"><legend class="legend">${t('report.category')}</legend>
      ${CATEGORIES.map((c) => html`<label class="chip"><input type="radio" name="category" value="${c}" ${d.category === c ? 'checked' : ''}><span>${t(`cat.${c}`)}</span></label>`)}
    </fieldset>
    <label class="field"><span>${t('report.zone')}</span>
      <select class="input" name="zone">${zones.map((z) => html`<option value="${z}" ${d.zone === z ? 'selected' : ''}>${t(`zone.${state.me.worker.industry}.${z}`)}</option>`)}</select></label>
    <label class="field"><span>${t('report.text')}</span>
      <textarea name="text" maxlength="600" placeholder="${t('report.placeholder')}" required>${d.text}</textarea>
      <small id="mic-status" aria-live="polite">${canDictate ? '' : t('report.mic.unsupported')}</small></label>
    ${canDictate ? html`<button type="button" class="btn btn--quiet" data-action="mic" id="mic-btn">${icon('mic')} <span>${t('report.mic')}</span></button>` : ''}
    <label class="callout callout--ok" for="anon"><span class="row"><input type="checkbox" id="anon" name="anonymous" ${d.anonymous ? 'checked' : ''}>
      <strong>${icon('shield')} ${t('report.anon')}</strong></span><span class="small muted">${t('report.anon.help')}</span></label>
    <button class="btn btn--primary btn--block" type="submit">${t('report.send')}</button>
  </form>`;
}

function reportSent(res) {
  return html`<div class="panel"><h2>${icon('check')} ${t('report.sent')}</h2>
    ${res.grievance.urgency === 'urgent' ? html`<p class="badge badge--alert">${t('report.urgent')}</p>` : ''}
    ${res.trackingCode ? html`<div class="callout callout--warn"><p>${t('report.code')}</p><p><strong class="num" style="font-size:1.8rem">${res.trackingCode}</strong></p><p class="small">${t('report.code.save')}</p></div>` : html`<p>${t('report.sent.help')}</p>`}
    <button class="btn" data-action="report-again">${t('report.again')}</button></div>`;
}

function feedbackForm() {
  if (state.feedbackDone) return html`<div class="panel"><h2>${icon('check')} ${t('fb.thanks')}</h2><p class="muted">${t('fb.thanks.help')}</p></div>`;
  return html`<form data-form="feedback" novalidate>
    <div class="callout callout--ok"><strong>${icon('shield')} ${t('fb.title')}</strong><p class="small">${t('fb.privacy', { min: 5 })}</p></div>
    <p class="muted small">${t('fb.scale')}</p>
    ${FEEDBACK_QUESTIONS.map((q) => html`<fieldset class="rating"><legend>${t(`fb.q.${q}`)}</legend>
      ${[1, 2, 3, 4, 5].map((n) => html`<label class="chip"><input type="radio" name="${q}" value="${n}" required><span><span aria-hidden="true">${['😠', '🙁', '😐', '🙂', '😀'][n - 1]}</span><span class="sr-only">${n}</span></span></label>`)}</fieldset>`)}
    <label class="field"><span>${t('fb.comment')}</span><textarea name="comment" maxlength="400"></textarea></label>
    <button class="btn btn--primary btn--block" type="submit">${t('fb.send')}</button>
  </form>`;
}

async function mineList() {
  const { grievances } = await api('/api/me/grievances');
  const anon = [];
  for (const code of savedCodes()) {
    try { anon.push({ code, ...(await api(`/api/grievances/track/${code}`)).grievance }); } catch { /* unknown or expired code */ }
  }
  const card = (g, code) => html`<article class="item"><div class="item__top"><div><div class="item__title">${t(`cat.${g.category}`)}${code ? html` · <span class="num">${code}</span>` : ''}</div>
      <div class="item__meta">${fmt.dateTime(g.createdAt)} · ${t(`zone.${state.me.worker.industry}.${g.zone}`)}</div></div>${statusBadge(g.status)}</div>
    <p>${g.text}</p>
    <ol class="timeline">${g.history.map((h) => html`<li class="${h.status === 'resolved' ? 'is-done' : ''}"><strong>${t(`status.${h.status}`)}</strong> · <span class="muted">${fmt.dateTime(h.at)}</span>${h.note ? html`<br>${h.note}` : ''}</li>`)}</ol></article>`;
  return html`${grievances.length + anon.length === 0 ? html`<div class="empty">${t('mine.empty')}</div>` : ''}
    ${grievances.map((g) => card(g))}${anon.map((g) => card(g, g.code))}
    <form class="panel" data-form="track" style="margin-top:1rem"><label class="field"><span>${t('mine.track')}</span>
      <input type="text" name="code" placeholder="FS-XXXXX" autocapitalize="characters" autocomplete="off"></label>
      <button class="btn btn--sm" type="submit">${t('mine.track.go')}</button></form>`;
}

async function viewSpeak() {
  const tabs = ['report', 'feedback', 'mine'];
  const body = state.speakTab === 'report' ? (state.lastReport ? reportSent(state.lastReport) : reportForm())
    : state.speakTab === 'feedback' ? feedbackForm() : await mineList();
  render(view, html`<div class="segment" role="group" aria-label="${t('nav.speak')}">
    ${tabs.map((id) => html`<button data-action="speak-tab" data-tab="${id}" aria-pressed="${state.speakTab === id}">${t(`speak.tab.${id}`)}</button>`)}</div>${body}`);
}

function syncDraft(form) {
  const data = new FormData(form);
  state.draft = { category: data.get('category') || 'other', zone: data.get('zone') || 'other', text: data.get('text') || '', anonymous: data.get('anonymous') === 'on' };
}

async function sendReport(form) {
  syncDraft(form);
  if (state.draft.text.trim().length < 5) { toast(t('err.too_short'), 'error'); return; }
  try {
    const res = await api('/api/grievances', { method: 'POST', body: state.draft });
    if (res.trackingCode) saveCode(res.trackingCode);
    state.lastReport = res;
    state.draft = { category: 'safety', zone: 'other', text: '', anonymous: false };
    await show('speak');
  } catch (err) {
    toast(errorMessage(err), 'error');
  }
}

async function sendFeedback(form) {
  const data = new FormData(form);
  const ratings = {};
  for (const q of FEEDBACK_QUESTIONS) ratings[q] = Number(data.get(q));
  if (Object.values(ratings).some((n) => !n)) { toast(t('fb.incomplete'), 'error'); return; }
  try {
    await api('/api/feedback', { method: 'POST', body: { ratings, comment: data.get('comment') || '' } });
    state.feedbackDone = true;
    await show('speak');
  } catch (err) {
    if (err.code === 'already_submitted') { state.feedbackDone = true; await show('speak'); }
    toast(errorMessage(err), err.code === 'already_submitted' ? '' : 'error');
  }
}

function toggleDictation(button) {
  const status = document.getElementById('mic-status');
  const textarea = view.querySelector('textarea[name="text"]');
  if (state.stopDictation) { state.stopDictation(); return; }
  const base = textarea.value ? `${textarea.value} ` : '';
  button.classList.add('mic-live');
  button.querySelector('span').textContent = t('report.mic.stop');
  status.textContent = t('report.mic.listening');
  const finish = () => {
    state.stopDictation = null;
    button.classList.remove('mic-live');
    button.querySelector('span').textContent = t('report.mic');
    status.textContent = '';
    state.draft.text = textarea.value;
  };
  state.stopDictation = startDictation(getLang(), {
    onText: (text) => { textarea.value = base + text; },
    onEnd: finish,
    onError: () => { finish(); toast(t('report.mic.error'), 'error'); },
  });
}

/* ------------------------------------------------------------------ */
/* Passport                                                            */
/* ------------------------------------------------------------------ */

function entryCard(e, by) {
  const when = e.kind === 'experience'
    ? `${fmt.dateKey(e.startDate, { month: 'short', year: 'numeric' })} – ${e.endDate ? fmt.dateKey(e.endDate, { month: 'short', year: 'numeric' }) : t('pp.present')}`
    : e.date ? fmt.dateKey(e.date, { day: 'numeric', month: 'short', year: 'numeric' }) : '';
  return html`<article class="item"><div class="item__top"><div><div class="item__title">${e.title}</div>
      <div class="item__meta">${[e.org, when].filter(Boolean).join(' · ')}</div></div>
      <span class="badge badge--info">${t(`pp.kind.${e.kind}`)}</span></div>
    <div class="row">
      ${e.status === 'verified' ? html`<span class="badge badge--ok">${icon('check')} ${t('pp.badge.verified', { by: e.verifiedBy })}</span>` : html`<span class="badge">${t('pp.badge.self')}</span>`}
      ${e.expiry === 'expiring' ? html`<span class="badge badge--warn">${t('pp.expiry.expiring', { date: fmt.dateKey(e.expiresOn, { day: 'numeric', month: 'short', year: 'numeric' }) })}</span>` : ''}
      ${e.expiry === 'expired' ? html`<span class="badge badge--alert">${t('pp.expiry.expired', { date: fmt.dateKey(e.expiresOn, { day: 'numeric', month: 'short', year: 'numeric' }) })}</span>` : ''}
      ${e.status !== 'verified' ? html`<button class="btn btn--quiet btn--sm" data-action="pp-delete" data-id="${e.id}" aria-label="${t('pp.delete')}: ${e.title}">${icon('trash')} ${t('pp.delete')}</button>` : ''}
    </div></article>`;
}

function addForm() {
  const kind = state.addKind;
  const isExp = kind === 'experience';
  return html`<form class="panel" data-form="entry" novalidate aria-labelledby="add-h"><h2 id="add-h">${t('pp.add')}</h2>
    <fieldset class="chips"><legend class="legend">${t('pp.f.kind')}</legend>
      ${['certification', 'training', 'experience'].map((k) => html`<label class="chip"><input type="radio" name="kind" value="${k}" ${kind === k ? 'checked' : ''}><span>${t(`pp.kind.${k}`)}</span></label>`)}</fieldset>
    <label class="field"><span>${t('pp.f.title')}</span><input type="text" name="title" list="skills" maxlength="80" required>
      <datalist id="skills">${state.me.industry.skillSuggestions.map((s) => html`<option value="${s}">`)}</datalist></label>
    <label class="field"><span>${t('pp.f.org')}</span><input type="text" name="org" maxlength="80"></label>
    ${isExp ? html`<div class="row"><label class="field grow"><span>${t('pp.f.start')}</span><input type="date" name="startDate" required></label>
      <label class="field grow"><span>${t('pp.f.end')}</span><input type="date" name="endDate"></label></div>`
    : html`<div class="row"><label class="field grow"><span>${t('pp.f.date')}</span><input type="date" name="date"></label>
      <label class="field grow"><span>${t('pp.f.expires')}</span><input type="date" name="expiresOn"></label></div>`}
    <div class="row"><button class="btn btn--primary" type="submit">${t('pp.save')}</button><button class="btn btn--quiet" type="button" data-action="pp-add-close">${t('common.cancel')}</button></div></form>`;
}

async function viewPassport() {
  const pp = await api('/api/me/passport');
  const s = pp.summary;
  const link = pp.shareToken ? `${location.origin}/passport.html?t=${pp.shareToken}` : '';
  const entries = [...s.entries].sort((a, b) => a.kind.localeCompare(b.kind) || String(b.date || b.startDate).localeCompare(String(a.date || a.startDate)));
  render(view, html`
    <section class="passport-head" aria-labelledby="pp-h"><h1 id="pp-h">${t('pp.title')}</h1>
      <p class="muted">${state.me.worker.name} · ${state.me.worker.role}</p>
      <span class="passport-id">${pp.passportId}</span>
      <div class="stats">
        <div class="stat"><strong>${fmt.num(s.experienceYears)}</strong><span>${t('pp.years')}</span></div>
        <div class="stat"><strong>${s.counts.certification + s.counts.training}</strong><span>${t('pp.certs')}</span></div>
        <div class="stat"><strong>${s.counts.verified}</strong><span>${t('pp.verified')}</span></div>
        <div class="stat"><strong>${fmt.num(s.loggedHours, 0)}</strong><span>${t('pp.hours', { employer: pp.employer })}</span></div>
      </div></section>
    <p class="muted">${t('pp.sub')}</p>
    ${state.addOpen ? addForm() : html`<button class="btn btn--primary btn--block" data-action="pp-add-open">${icon('plus')} ${t('pp.add')}</button>`}
    <div style="margin-top:1rem">${entries.length ? entries.map((e) => entryCard(e)) : html`<div class="empty">${t('pp.empty')}</div>`}</div>
    <section class="panel" style="margin-top:1rem" aria-labelledby="share-h"><div class="panel__head"><h2 id="share-h">${icon('share')} ${t('pp.share')}</h2>
      <span class="badge ${pp.shareEnabled ? 'badge--ok' : ''}">${pp.shareEnabled ? t('pp.share.on') : t('pp.share.off')}</span></div>
      <p class="muted small">${t('pp.share.help')}</p>
      ${pp.shareEnabled ? html`<label class="field"><span class="sr-only">${t('pp.share')}</span><input type="text" readonly value="${link}" id="share-link"></label>
        <div class="row"><button class="btn btn--sm" data-action="pp-copy" data-link="${link}">${icon('copy')} ${t('pp.share.copy')}</button>
        <a class="btn btn--sm" href="${link}" target="_blank" rel="noopener">${t('pp.share.open')}</a>
        <button class="btn btn--sm btn--quiet" data-action="pp-share-off">${t('pp.share.stop')}</button></div>`
    : html`<button class="btn" data-action="pp-share-on">${icon('share')} ${t('pp.share.start')}</button>`}</section>`);
}

async function saveEntry(form) {
  const data = Object.fromEntries(new FormData(form));
  Object.keys(data).forEach((k) => { if (data[k] === '') delete data[k]; });
  try {
    await api('/api/me/passport/entries', { method: 'POST', body: data });
    state.addOpen = false;
    toast(t('pp.saved'), 'ok');
    await show('passport');
  } catch (err) {
    toast(errorMessage(err), 'error');
  }
}

/* ------------------------------------------------------------------ */
/* events                                                              */
/* ------------------------------------------------------------------ */

const actions = {
  reload: () => show(),
  'checkin-toggle': () => { state.checkinOpen = !state.checkinOpen; return show('today'); },
  checkout: () => checkOut(),
  scan: () => openScanner(),
  'scan-close': () => closeScanner(),
  geo: () => useLocation(false),
  'demo-geo': () => useLocation(true),
  'demo-qr': () => submitCheckIn({ method: 'qr', code: state.me.demoSiteCode }),
  'report-fatigue': () => {
    const f = state.today.fatigue;
    state.draft = { category: 'schedule', zone: 'other', anonymous: false, text: t('today.rest.draft', { hours: fmt.num(f.weeklyHours), days: f.consecutiveDays }) };
    state.speakTab = 'report';
    location.hash = '#speak';
  },
  'month-prev': () => { state.month = shiftMonth(state.month, -1); return show('pay'); },
  'month-next': () => { state.month = shiftMonth(state.month, 1); return show('pay'); },
  listen: () => {
    const p = state.payslip;
    speak(t('pay.speech', { month: fmt.month(p.month), days: p.totals.daysWorked, gross: fmt.num(p.gross, 0), net: fmt.num(p.net, 0) }), getLang());
  },
  dispute: (el) => {
    state.draft = { category: 'pay', zone: 'other', anonymous: false, text: t('pay.dispute.text', { date: fmt.dateKey(el.dataset.date, { day: 'numeric', month: 'long' }) }) };
    state.speakTab = 'report';
    state.lastReport = null;
    location.hash = '#speak';
  },
  'speak-tab': (el) => { state.speakTab = el.dataset.tab; if (el.dataset.tab !== 'report') state.lastReport = state.lastReport; return show('speak'); },
  'report-again': () => { state.lastReport = null; return show('speak'); },
  mic: (el) => toggleDictation(el.closest('button')),
  'pp-add-open': () => { state.addOpen = true; return show('passport'); },
  'pp-add-close': () => { state.addOpen = false; return show('passport'); },
  'pp-delete': async (el) => {
    try { await api(`/api/me/passport/entries/${el.dataset.id}`, { method: 'DELETE' }); toast(t('pp.removed')); await show('passport'); } catch (err) { toast(errorMessage(err), 'error'); }
  },
  'pp-share-on': async () => { await api('/api/me/passport/share', { method: 'POST', body: { enabled: true } }); await show('passport'); },
  'pp-share-off': async () => { await api('/api/me/passport/share', { method: 'POST', body: { enabled: false } }); await show('passport'); },
  'pp-copy': async (el) => {
    try { await navigator.clipboard.writeText(el.dataset.link); toast(t('pp.share.copied'), 'ok'); } catch { document.getElementById('share-link')?.select(); toast(t('pp.share.copyfail')); }
  },
};

view.addEventListener('click', (event) => {
  const el = event.target.closest('[data-action]');
  if (el && actions[el.dataset.action]) actions[el.dataset.action](el);
});

view.addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.target;
  const kind = form.dataset.form;
  if (kind === 'code') {
    const code = form.querySelector('input').value.trim();
    if (code) submitCheckIn({ method: 'qr', code });
  } else if (kind === 'report') sendReport(form);
  else if (kind === 'feedback') sendFeedback(form);
  else if (kind === 'entry') saveEntry(form);
  else if (kind === 'track') {
    const code = new FormData(form).get('code').trim().toUpperCase();
    if (!code) return;
    try { await api(`/api/grievances/track/${code}`); saveCode(code); await show('speak'); } catch { toast(t('mine.notfound'), 'error'); }
  }
});

view.addEventListener('change', (event) => {
  const form = event.target.closest('form');
  if (!form) return;
  if (form.dataset.form === 'report') syncDraft(form);
  if (form.dataset.form === 'entry' && event.target.name === 'kind') { state.addKind = event.target.value; show('passport'); }
});
view.addEventListener('input', (event) => {
  if (event.target.name === 'text') state.draft.text = event.target.value;
});

window.addEventListener('hashchange', () => {
  const id = location.hash.slice(1);
  if (TABS.some(([tab]) => tab === id)) show(id);
});

document.getElementById('signout').addEventListener('click', () => { session.clear(); location.href = '/'; });

/* ------------------------------------------------------------------ */
/* start                                                               */
/* ------------------------------------------------------------------ */

async function start() {
  if (!session.require('worker')) return;
  initLanguageSelect(document.getElementById('lang'), () => { applyI18n(document); show(); });
  try {
    state.me = await api('/api/me');
  } catch (err) {
    toast(errorMessage(err), 'error');
    return;
  }
  const initial = location.hash.slice(1);
  await show(TABS.some(([tab]) => tab === initial) ? initial : 'today');
}

start();
