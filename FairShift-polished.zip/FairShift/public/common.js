// Shared helpers used by every page. No framework, no build step.
import { t, locale } from './i18n.js';

/* ---------- safe HTML templating ---------- */
// Values interpolated into html`...` are escaped unless they are themselves html`...` results.

class Safe {
  constructor(text) { this.text = text; }
  toString() { return this.text; }
}
const ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ESCAPES[c]);
const part = (v) => (v instanceof Safe ? v.text : Array.isArray(v) ? v.map(part).join('') : esc(v));

export function html(strings, ...values) {
  return new Safe(strings.reduce((out, s, i) => out + s + (i < values.length ? part(values[i]) : ''), ''));
}
export const unsafeHtml = (text) => new Safe(text); // only for trusted, app-generated markup (e.g. the QR SVG)

export function render(target, content) {
  target.innerHTML = content instanceof Safe ? content.text : String(content);
}

/* ---------- icons ---------- */
const ICONS = {
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  receipt: '<path d="M4 2h16v20l-3-2-3 2-3-2-3 2-4-2z"/><line x1="8" y1="8" x2="16" y2="8"/><line x1="8" y1="12" x2="16" y2="12"/>',
  speak: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  passport: '<circle cx="12" cy="8" r="6"/><path d="M15.5 13.5 17 22l-5-3-5 3 1.5-8.5"/>',
  mic: '<path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/>',
  scan: '<path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><rect x="7" y="7" width="10" height="10" rx="1"/>',
  pin: '<path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
  alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"/><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
  volume: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/>',
  printer: '<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
  chevronLeft: '<polyline points="15 18 9 12 15 6"/>',
  chevronRight: '<polyline points="9 18 15 12 9 6"/>',
  hardhat: '<path d="M2 18h20v2H2z"/><path d="M4 18a8 8 0 0 1 16 0"/><path d="M10 10V5h4v5"/>',
  school: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11.5V16c0 1.5 3 3 6 3s6-1.5 6-3v-4.5"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
};
export const icon = (name) => new Safe(`<svg class="icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${ICONS[name] || ''}</svg>`);

/* ---------- session ---------- */
const SESSION_KEY = 'fs.session';
export const session = {
  get() {
    try { return JSON.parse(sessionStorage.getItem(SESSION_KEY)); } catch { return null; }
  },
  set(value) { sessionStorage.setItem(SESSION_KEY, JSON.stringify(value)); },
  clear() { sessionStorage.removeItem(SESSION_KEY); },
  /** Return the session for a role, or send the visitor back to the start page. */
  require(role) {
    const s = session.get();
    if (!s || s.role !== role) {
      location.replace('/');
      return null;
    }
    return s;
  },
};

/* ---------- API ---------- */
export class ApiError extends Error {
  constructor(code, status, details = {}) {
    super(code);
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

export async function api(path, { method = 'GET', body } = {}) {
  const s = session.get();
  let res;
  try {
    res = await fetch(path, {
      method,
      headers: { ...(s ? { Authorization: `Bearer ${s.token}` } : {}), ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError('network', 0);
  }
  const contentType = res.headers.get('content-type') || '';
  const data = contentType.includes('json') ? await res.json().catch(() => ({})) : null;
  if (!res.ok) {
    if (res.status === 401 && s) {
      session.clear();
      location.replace('/');
    }
    throw new ApiError(data?.error || 'generic', res.status, data || {});
  }
  return data;
}

export function errorMessage(err) {
  const code = err instanceof ApiError ? err.code : 'generic';
  const key = `err.${code}`;
  const text = t(key, err.details);
  return text === key ? t('err.generic') : text;
}

/* ---------- toast ---------- */
let toastTimer;
export function toast(message, kind = '') {
  let el = document.getElementById('toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
    document.body.append(el);
  }
  el.className = `toast ${kind ? `toast--${kind}` : ''}`;
  el.textContent = message;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.hidden = true; }, 4500);
}

/* ---------- formatting (always Indian Standard Time) ---------- */
const TZ = 'Asia/Kolkata';
export const fmt = {
  money: (n) => `₹${Number(n).toLocaleString(locale(), { maximumFractionDigits: 2, minimumFractionDigits: Number.isInteger(n) ? 0 : 2 })}`,
  num: (n, digits = 1) => Number(n).toLocaleString(locale(), { maximumFractionDigits: digits }),
  time: (iso) => new Date(iso).toLocaleTimeString(locale(), { hour: '2-digit', minute: '2-digit', timeZone: TZ }),
  dateKey: (key, opts = { day: 'numeric', month: 'short' }) => new Date(`${key}T00:00:00+05:30`).toLocaleDateString(locale(), { ...opts, timeZone: TZ }),
  dateTime: (iso) => new Date(iso).toLocaleString(locale(), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', timeZone: TZ }),
  month: (key) => new Date(`${key}-15T00:00:00+05:30`).toLocaleDateString(locale(), { month: 'long', year: 'numeric', timeZone: TZ }),
  weekday: (key) => new Date(`${key}T00:00:00+05:30`).toLocaleDateString(locale(), { weekday: 'narrow', timeZone: TZ }),
};

/** YYYY-MM for "now" in IST. */
export const currentMonth = () => new Date(Date.now() + 330 * 60000).toISOString().slice(0, 7);
export function shiftMonth(key, delta) {
  const [y, m] = key.split('-').map(Number);
  const d = new Date(Date.UTC(y, m - 1 + delta, 1));
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
}

/** SVG progress bar built from attributes only (CSP forbids inline styles). */
export function bar(value, max, tone = '', label = '') {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return html`<svg class="bar" viewBox="0 0 100 8" preserveAspectRatio="none" role="img" aria-label="${label}"><rect class="bar__track" width="100" height="8" rx="4"/><rect class="bar__fill ${tone ? `bar__fill--${tone}` : ''}" width="${pct}" height="8" rx="4"/></svg>`;
}

export function debounce(fn, ms) {
  let id;
  return (...args) => { clearTimeout(id); id = setTimeout(() => fn(...args), ms); };
}
