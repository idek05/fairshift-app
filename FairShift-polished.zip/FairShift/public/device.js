// Browser device features. Every function degrades gracefully when unsupported
// (cheap phones, older browsers): callers check the `can*` flags first.

const LANG_TAGS = { en: 'en-IN', ta: 'ta-IN', hi: 'hi-IN' };

/* ---------- voice typing ---------- */
const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
export const canDictate = Boolean(Recognition);

/**
 * Start speech-to-text. `onText` receives the full transcript so far.
 * Returns a stop() function.
 */
export function startDictation(lang, { onText, onEnd, onError }) {
  const rec = new Recognition();
  rec.lang = LANG_TAGS[lang] || 'en-IN';
  rec.interimResults = true;
  rec.continuous = false;
  rec.onresult = (event) => {
    onText(Array.from(event.results).map((r) => r[0].transcript).join(' ').trim());
  };
  rec.onerror = (event) => onError?.(event.error);
  rec.onend = () => onEnd?.();
  rec.start();
  return () => rec.stop();
}

/* ---------- read aloud ---------- */
export const canSpeak = 'speechSynthesis' in window;

export function speak(text, lang) {
  if (!canSpeak) return false;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = LANG_TAGS[lang] || 'en-IN';
  utterance.rate = 0.9;
  window.speechSynthesis.speak(utterance);
  return true;
}

/* ---------- QR scanning ---------- */
export const canScanQr = 'BarcodeDetector' in window && Boolean(navigator.mediaDevices?.getUserMedia);

/** Open the rear camera in `video` and call `onCode` with the first QR value. Returns stop(). */
export async function startQrScan(video, onCode) {
  const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
  video.srcObject = stream;
  await video.play();
  const detector = new window.BarcodeDetector({ formats: ['qr_code'] });
  let stopped = false;
  const stop = () => {
    stopped = true;
    stream.getTracks().forEach((track) => track.stop());
    video.srcObject = null;
  };
  const tick = async () => {
    if (stopped) return;
    try {
      const [code] = await detector.detect(video);
      if (code) {
        stop();
        onCode(code.rawValue);
        return;
      }
    } catch { /* keep scanning */ }
    setTimeout(tick, 250);
  };
  tick();
  return stop;
}

/* ---------- location ---------- */
export function getPosition() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('unsupported'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      (err) => reject(err),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 30000 },
    );
  });
}
