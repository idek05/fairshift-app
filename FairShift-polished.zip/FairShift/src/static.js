'use strict';
/** Minimal static file server: in-memory cache, gzip, ETag, no path traversal. */

const fs = require('node:fs/promises');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json',
};
const COMPRESSIBLE = new Set(['.html', '.css', '.js', '.json', '.svg', '.webmanifest']);

function createStatic(root) {
  const base = path.resolve(root);
  const cache = new Map();

  async function load(file) {
    if (cache.has(file)) return cache.get(file);
    const ext = path.extname(file);
    const body = await fs.readFile(file);
    const entry = {
      body,
      gzip: COMPRESSIBLE.has(ext) ? zlib.gzipSync(body) : null,
      type: MIME[ext] || 'application/octet-stream',
      etag: `"${crypto.createHash('sha1').update(body).digest('hex').slice(0, 16)}"`,
      html: ext === '.html',
    };
    cache.set(file, entry);
    return entry;
  }

  /** Returns true when the request was answered. */
  return async function serve(req, res, pathname) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return false;
    let rel;
    try {
      rel = decodeURIComponent(pathname);
    } catch {
      return false;
    }
    if (rel.endsWith('/')) rel += 'index.html';
    const file = path.join(base, path.normalize(rel));
    if (!file.startsWith(base + path.sep)) return false;

    let entry;
    try {
      entry = await load(file);
    } catch {
      return false;
    }

    const headers = {
      'Content-Type': entry.type,
      ETag: entry.etag,
      'Cache-Control': entry.html ? 'no-cache' : 'public, max-age=300',
      Vary: 'Accept-Encoding',
    };
    if (req.headers['if-none-match'] === entry.etag) {
      res.writeHead(304, headers);
      res.end();
      return true;
    }
    const useGzip = entry.gzip && /\bgzip\b/.test(req.headers['accept-encoding'] || '');
    const payload = useGzip ? entry.gzip : entry.body;
    if (useGzip) headers['Content-Encoding'] = 'gzip';
    headers['Content-Length'] = payload.length;
    res.writeHead(200, headers);
    res.end(req.method === 'HEAD' ? undefined : payload);
    return true;
  };
}

module.exports = { createStatic };
