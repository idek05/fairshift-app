'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const L = require('../src/logic');
const { INDUSTRIES } = require('../src/data');
const { csvCell, createRateLimiter, createAuth, cleanText, optionalDate } = require('../src/security');

const RULES = INDUSTRIES.construction.rules;
const NOW = Date.parse('2026-10-27T10:00:00Z'); // 15:30 IST on 27 Oct 2026

/** A completed shift on an IST date, starting at `startHour` and lasting `hours`. */
function shift(date, startHour, hours, extra = {}) {
  const checkIn = L.istMidnight(date) + startHour * L.HOUR_MS;
  return {
    id: `${date}-${startHour}`, workerId: 'w', method: 'qr', ...extra,
    checkIn: new Date(checkIn).toISOString(),
    checkOut: new Date(checkIn + hours * L.HOUR_MS).toISOString(),
  };
}

test('dateKey uses Indian Standard Time', () => {
  assert.equal(L.dateKey('2026-10-27T20:00:00Z'), '2026-10-28'); // 01:30 IST next day
  assert.equal(L.dateKey('2026-10-27T10:00:00Z'), '2026-10-27');
});

test('summarizeDays splits regular and overtime hours', () => {
  const days = L.summarizeDays([shift('2026-10-20', 8, 10), shift('2026-10-21', 8, 6)], RULES);
  assert.deepEqual(days.map((d) => [d.date, d.hours, d.regular, d.overtime]), [
    ['2026-10-20', 10, 8, 2],
    ['2026-10-21', 6, 6, 0],
  ]);
});

test('a night shift is counted on the day it started', () => {
  const [day] = L.summarizeDays([shift('2026-10-20', 22, 9)], RULES);
  assert.equal(day.date, '2026-10-20');
  assert.equal(day.hours, 9);
  assert.equal(day.overtime, 1);
});

test('open shifts are ignored by summarizeDays but can be closed for live views', () => {
  const open = { id: 'o', workerId: 'w', method: 'qr', checkIn: '2026-10-27T04:00:00Z', checkOut: null };
  assert.equal(L.summarizeDays([open], RULES).length, 0);
  const [day] = L.summarizeDays(L.closeOpenAt([open], NOW), RULES);
  assert.equal(day.hours, 6);
  assert.equal(day.live, true);
});

test('payslip: itemised earnings, deductions and net pay', () => {
  const worker = { id: 'w', hourlyRate: 100, advanceMonthly: 500 };
  const records = [shift('2026-10-01', 8, 8), shift('2026-10-02', 8, 10), shift('2026-10-03', 8, 6), shift('2026-09-30', 8, 8)];
  const p = L.computePayslip(worker, records, '2026-10', RULES);
  assert.equal(p.totals.daysWorked, 3);
  assert.equal(p.totals.regularHours, 22);
  assert.equal(p.totals.overtimeHours, 2);
  assert.equal(p.earnings[0].amount, 2200);
  assert.equal(p.earnings[1].amount, 400); // 2 h x 100 x 2.0
  assert.equal(p.gross, 2600);
  assert.equal(p.deductions.find((d) => d.code === 'pf').amount, 264);
  assert.equal(p.deductions.find((d) => d.code === 'esi').amount, 19.5);
  assert.equal(p.deductions.find((d) => d.code === 'advance').amount, 500);
  assert.equal(p.net, 1816.5);
  assert.equal(p.net, L.round2(p.gross - p.totalDeductions));
});

test('payslip: ESI is skipped above the wage ceiling and advance never exceeds earnings', () => {
  const high = L.computePayslip({ id: 'w', hourlyRate: 1000, advanceMonthly: 0 }, [shift('2026-10-01', 8, 8), shift('2026-10-02', 8, 8), shift('2026-10-03', 8, 8), shift('2026-10-04', 8, 8)], '2026-10', RULES);
  assert.ok(high.gross > RULES.esiCeiling);
  assert.equal(high.deductions.some((d) => d.code === 'esi'), false);

  const tiny = L.computePayslip({ id: 'w', hourlyRate: 50, advanceMonthly: 5000 }, [shift('2026-10-01', 8, 2)], '2026-10', RULES);
  assert.ok(tiny.net >= 0);
});

test('payslip for an empty month is all zeros', () => {
  const p = L.computePayslip({ id: 'w', hourlyRate: 100, advanceMonthly: 500 }, [], '2026-10', RULES);
  assert.equal(p.gross, 0);
  assert.equal(p.net, 0);
});

test('fatigue: a normal week is ok', () => {
  const records = ['21', '22', '23', '24', '26'].map((d) => shift(`2026-10-${d}`, 8, 8));
  const f = L.assessFatigue(records, RULES, NOW);
  assert.equal(f.level, 'ok');
  assert.equal(f.reasons.length, 0);
});

test('fatigue: weekly hours escalate from warning to high', () => {
  const week = (hours) => ['21', '22', '23', '24', '25'].map((d) => shift(`2026-10-${d}`, 8, hours));
  assert.equal(L.assessFatigue(week(9.6), RULES, NOW).reasons.some((r) => r.code === 'weekly_hours'), false); // exactly 48 h is within the limit
  assert.equal(L.assessFatigue(week(10.2), RULES, NOW).reasons.find((r) => r.code === 'weekly_hours').level, 'warn'); // 51 h
  assert.equal(L.assessFatigue(week(11.2), RULES, NOW).reasons.find((r) => r.code === 'weekly_hours').level, 'high'); // 56 h
});

test('fatigue: long days, no rest day and heavy weekly hours are flagged high', () => {
  const records = [];
  for (let d = 20; d <= 27; d += 1) records.push(shift(`2026-10-${d}`, 7, 11));
  const f = L.assessFatigue(records, { ...RULES }, NOW);
  assert.equal(f.level, 'high');
  const codes = f.reasons.map((r) => r.code);
  assert.ok(codes.includes('weekly_hours'));
  assert.ok(codes.includes('consecutive_days'));
  assert.ok(codes.includes('long_days'));
  assert.equal(f.consecutiveDays, 8);
});

test('fatigue: back-to-back shifts with too little rest are caught', () => {
  const records = [shift('2026-10-24', 14, 8.5), shift('2026-10-25', 6, 8.5)]; // 7.5 h rest
  const f = L.assessFatigue(records, RULES, NOW);
  const rest = f.reasons.find((r) => r.code === 'short_rest');
  assert.ok(rest);
  assert.equal(rest.minRestHours, 7.5);
  assert.equal(f.level, 'warn');
});

test('fatigue: two shifts on the same day (a lunch break) are not "short rest"', () => {
  const f = L.assessFatigue([shift('2026-10-26', 7, 4), shift('2026-10-26', 12, 4)], RULES, NOW);
  assert.equal(f.shortRests, 0);
});

test('attrition risk is explainable and capped', () => {
  const worker = { id: 'w', joinedOn: '2026-08-01' };
  const records = [shift('2026-10-20', 8, 8)];
  const fatigue = L.assessFatigue(records, RULES, NOW);
  const grievances = [{ workerId: 'w', status: 'submitted', createdAt: new Date(NOW - 10 * 86400000).toISOString() }];
  const risk = L.assessAttritionRisk({ worker, records, grievances, fatigue, rules: RULES, nowTs: NOW });
  assert.ok(risk.score > 0 && risk.score <= 100);
  const codes = risk.factors.map((f) => f.code);
  assert.ok(codes.includes('absence'));
  assert.ok(codes.includes('open_complaints'));
  assert.ok(codes.includes('tenure'));
  assert.equal(risk.score, risk.factors.reduce((t, f) => t + f.points, 0));
  assert.equal(risk.level, 'high');
});

test('attrition risk is low for a steady long-serving worker', () => {
  const worker = { id: 'w', joinedOn: '2020-01-01' };
  const records = [];
  for (let d = 1; d <= 26; d += 1) if (d % 7 !== 0) records.push(shift(`2026-10-${String(d).padStart(2, '0')}`, 8, 8));
  const fatigue = L.assessFatigue(records, RULES, NOW);
  const risk = L.assessAttritionRisk({ worker, records, grievances: [], fatigue, rules: RULES, nowTs: NOW });
  assert.equal(risk.level, 'low');
});

test('urgency detection escalates physical dangers', () => {
  assert.equal(L.detectUrgency('Exposed wire near the canteen', 'safety'), 'urgent');
  assert.equal(L.detectUrgency('Helmet strap is loose', 'safety'), 'high');
  assert.equal(L.detectUrgency('Someone fell from the scaffold', 'other'), 'high');
  assert.equal(L.detectUrgency('Please share the holiday list', 'other'), 'normal');
  assert.equal(L.detectUrgency('மின்சார கம்பி ஆபத்து', 'safety'), 'urgent');
});

test('feedback stays hidden until enough people respond', () => {
  const entry = (n) => ({ ratings: { manager: n, safety: n, pay: n, workplace: n }, comment: '', themes: [] });
  assert.equal(L.aggregateFeedback([entry(3), entry(4), entry(5), entry(2)]).visible, false);
  const agg = L.aggregateFeedback([entry(3), entry(4), entry(5), entry(2), entry(1)]);
  assert.equal(agg.visible, true);
  assert.equal(agg.averages.manager, 3);
  assert.deepEqual(Object.keys(agg.comments), []);
});

test('feedback themes are detected in English, Tamil and Hindi', () => {
  assert.deepEqual(L.detectThemes('Overtime salary is late'), ['pay']);
  assert.ok(L.detectThemes('குடிநீர் இல்லை').includes('facilities'));
  assert.ok(L.detectThemes('वेतन देर से मिलता है').includes('pay'));
});

test('certificate expiry status', () => {
  assert.equal(L.certStatus({ expiresOn: null }, NOW), 'none');
  assert.equal(L.certStatus({ expiresOn: '2026-10-20' }, NOW), 'expired');
  assert.equal(L.certStatus({ expiresOn: '2026-11-15' }, NOW), 'expiring');
  assert.equal(L.certStatus({ expiresOn: '2027-06-01' }, NOW), 'valid');
});

test('passport experience years add up closed and ongoing roles', () => {
  const years = L.experienceYears([
    { kind: 'experience', startDate: '2019-03-01', endDate: '2023-03-01' },
    { kind: 'experience', startDate: '2024-10-27', endDate: null },
    { kind: 'certification', startDate: null },
  ], NOW);
  assert.ok(years > 5.9 && years < 6.1, `got ${years}`);
});

test('distanceMetres is accurate at short range', () => {
  assert.equal(Math.round(L.distanceMetres(13.085, 80.2101, 13.085, 80.2101)), 0);
  const d = L.distanceMetres(13.085, 80.2101, 13.087, 80.2101); // 0.002 deg latitude ~ 222 m
  assert.ok(d > 215 && d < 230, `got ${d}`);
});

/* ---------- security helpers ---------- */

test('csvCell neutralises formula injection and quotes special characters', () => {
  assert.equal(csvCell('=SUM(A1)'), "'=SUM(A1)");
  assert.equal(csvCell('a,b'), '"a,b"');
  assert.equal(csvCell('say "hi"'), '"say ""hi"""');
  assert.equal(csvCell(105), '105');
});

test('rate limiter blocks after the limit and resets after the window', () => {
  const allow = createRateLimiter();
  assert.equal(allow('k', 2, 1000, 0), true);
  assert.equal(allow('k', 2, 1000, 10), true);
  assert.equal(allow('k', 2, 1000, 20), false);
  assert.equal(allow('k', 2, 1000, 1500), true);
});

test('session tokens are signed, expire, and reject tampering', () => {
  const auth = createAuth('test-secret', 1000);
  const token = auth.issue({ role: 'worker', workerId: 'c1' }, 0);
  assert.equal(auth.verify(token, 500).workerId, 'c1');
  assert.equal(auth.verify(token, 2000), null);
  const [body, sig] = token.split('.');
  const forged = `${Buffer.from(JSON.stringify({ role: 'admin', exp: 9e15 })).toString('base64url')}.${sig}`;
  assert.equal(auth.verify(forged, 500), null);
  assert.equal(auth.verify(`${body}.x`, 500), null);
  assert.equal(createAuth('other-secret').verify(token, 500), null);
});

test('input cleaning strips control characters and enforces limits', () => {
  assert.equal(cleanText('  hello\u0000 world  '), 'hello world');
  assert.throws(() => cleanText('x'.repeat(10), { max: 5 }), { code: 'too_long' });
  assert.throws(() => cleanText('ab', { min: 5 }), { code: 'too_short' });
  assert.throws(() => cleanText(42), { code: 'invalid_input' });
  assert.equal(optionalDate('2026-02-28'), '2026-02-28');
  assert.throws(() => optionalDate('2026-02-30'), { code: 'invalid_date' });
});
