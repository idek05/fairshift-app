'use strict';
/**
 * FairShift HTTP app (zero dependencies).
 * `createApp()` returns a plain (req, res) handler, so tests can mount it on an
 * ephemeral port and production just passes it to http.createServer().
 */

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const logic = require('./logic');
const { INDUSTRIES, publicIndustry, TOKEN_ALPHABET } = require('./data');
const {
  createAuth, safeEqual, createRateLimiter, HttpError, cleanText, oneOf, optionalDate, monthParam, rating, csvCell,
} = require('./security');
const { createStatic } = require('./static');

const CATEGORIES = ['safety', 'pay', 'conduct', 'schedule', 'facilities', 'other'];
const ENTRY_KINDS = ['certification', 'training', 'experience'];
const URGENCY_RANK = { urgent: 0, high: 1, normal: 2 };
const MAX_BODY_BYTES = 32 * 1024;
const MAX_OPEN_SHIFT_HOURS = 16;

const SECURITY_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Frame-Options': 'DENY',
  'Permissions-Policy': 'geolocation=(self), microphone=(self), camera=(self)',
};

function createApp({ store, config }) {
  const auth = createAuth(config.secret);
  const allow = createRateLimiter();
  const serveStatic = createStatic(config.publicDir);
  const routes = [];

  /* ---------- routing ---------- */

  function route(method, pattern, access, handler) {
    const keys = [];
    const source = pattern.replace(/:([a-zA-Z]+)/g, (_, key) => {
      keys.push(key);
      return '([^/]+)';
    });
    routes.push({ method, access, keys, regex: new RegExp(`^${source}$`), handler });
  }

  /* ---------- shared helpers ---------- */

  const recordsOf = (workerId) => store.attendance.filter((r) => r.workerId === workerId);
  const workersOf = (industryId) => store.workers.filter((w) => w.industry === industryId);
  const workerById = (id) => store.workers.find((w) => w.id === id);
  const entriesOf = (workerId) => store.passport.filter((e) => e.workerId === workerId);

  const publicWorker = (w) => ({ id: w.id, name: w.name, role: w.role, industry: w.industry, passportId: w.passportId, hourlyRate: w.hourlyRate });

  function loggedHours(records, rules) {
    return logic.summarizeDays(records, rules).reduce((t, d) => t + d.hours, 0);
  }

  function grievanceView(g, { forAdmin = false } = {}) {
    const view = {
      id: g.id, category: g.category, text: g.text, zone: g.zone, urgency: g.urgency, status: g.status,
      createdAt: g.createdAt, history: g.history, anonymous: !g.workerId,
    };
    if (forAdmin) {
      const w = g.workerId ? workerById(g.workerId) : null;
      view.workerName = w ? w.name : null;
      view.workerRole = w ? w.role : null;
    }
    return view;
  }

  /** Everything the employer views need to know about one worker. */
  function analyse(worker, now) {
    const rules = INDUSTRIES[worker.industry].rules;
    const records = recordsOf(worker.id);
    const fatigue = logic.assessFatigue(records, rules, now);
    const risk = logic.assessAttritionRisk({ worker, records, grievances: store.grievances, fatigue, rules, nowTs: now });
    const open = records.find((r) => !r.checkOut);
    return { worker, records, fatigue, risk, open };
  }

  function newTrackingCode() {
    let code;
    do {
      code = `FS-${Array.from({ length: 5 }, () => TOKEN_ALPHABET[crypto.randomInt(TOKEN_ALPHABET.length)]).join('')}`;
    } while (store.grievances.some((g) => g.trackingCode === code));
    return code;
  }

  const weekKey = (now) => {
    const today = logic.dateKey(now);
    return logic.addDays(today, -logic.weekday(today));
  };

  const reply = (data, status = 200) => ({ status, data });

  /* ---------- public routes ---------- */

  route('GET', '/healthz', 'public', () => reply({ ok: true }));

  route('GET', '/api/industries', 'public', () =>
    reply({
      industries: Object.values(INDUSTRIES).map(publicIndustry),
      demoMode: config.demoMode,
      adminPasscodeRequired: Boolean(config.adminPasscode),
    }));

  route('GET', '/api/demo-workers', 'public', ({ query }) => {
    if (!config.demoMode) throw new HttpError(404, 'not_found');
    const industry = oneOf(query.get('industry'), Object.keys(INDUSTRIES), 'industry');
    return reply({ workers: workersOf(industry).map((w) => ({ id: w.id, name: w.name, role: w.role })) });
  });

  route('POST', '/api/session', 'public', ({ body, ip }) => {
    if (!allow(`login:${ip}`, 30, 60000)) throw new HttpError(429, 'rate_limited');
    const role = oneOf(body.role, ['worker', 'admin'], 'role');
    const industry = oneOf(body.industry, Object.keys(INDUSTRIES), 'industry');
    if (role === 'admin') {
      if (config.adminPasscode) {
        if (!safeEqual(body.passcode ?? '', config.adminPasscode)) throw new HttpError(401, 'bad_passcode');
      } else if (!config.demoMode) {
        throw new HttpError(403, 'login_disabled');
      }
      return reply({ token: auth.issue({ role, industry }, config.now()), role, industry });
    }
    if (!config.demoMode) throw new HttpError(403, 'login_disabled');
    const worker = workerById(body.workerId);
    if (!worker || worker.industry !== industry) throw new HttpError(404, 'not_found');
    return reply({ token: auth.issue({ role, industry, workerId: worker.id }, config.now()), role, industry, worker: publicWorker(worker) });
  });

  route('GET', '/api/passport/:token', 'public', ({ params, ip }) => {
    if (!allow(`passport:${ip}`, 60, 60000)) throw new HttpError(429, 'rate_limited');
    const worker = store.workers.find((w) => w.shareToken && w.shareToken === params.token);
    if (!worker) throw new HttpError(404, 'not_found');
    const industry = INDUSTRIES[worker.industry];
    const summary = logic.passportSummary(entriesOf(worker.id), loggedHours(recordsOf(worker.id), industry.rules), config.now());
    return reply({ name: worker.name, role: worker.role, passportId: worker.passportId, employer: industry.employer, summary });
  });

  /* ---------- worker: profile & attendance ---------- */

  route('GET', '/api/me', 'worker', ({ worker }) => {
    const industry = INDUSTRIES[worker.industry];
    return reply({
      worker: publicWorker(worker),
      industry: publicIndustry(industry),
      demoSiteCode: config.demoMode ? industry.site.code : undefined,
    });
  });

  route('GET', '/api/me/today', 'worker', ({ worker, now }) => {
    const { rules } = INDUSTRIES[worker.industry];
    const records = recordsOf(worker.id);
    const fatigue = logic.assessFatigue(records, rules, now);
    const open = records.find((r) => !r.checkOut);
    const days = logic.summarizeDays(logic.closeOpenAt(records, now), rules);
    const today = logic.dateKey(now);
    const week = Array.from({ length: 7 }, (_, i) => {
      const date = logic.addDays(today, i - 6);
      const day = days.find((d) => d.date === date);
      return { date, hours: day ? day.hours : 0 };
    });
    return reply({
      openShift: open ? { checkIn: open.checkIn, method: open.method } : null,
      week,
      weeklyLimit: rules.weeklyLimit,
      fatigue,
    });
  });

  route('POST', '/api/me/check-in', 'worker', ({ worker, body, now }) => {
    const industry = INDUSTRIES[worker.industry];
    const method = oneOf(body.method, ['qr', 'geo'], 'method');

    if (method === 'qr') {
      const code = cleanText(body.code, { max: 60, min: 1, field: 'code' });
      if (!safeEqual(code, industry.site.code)) throw new HttpError(400, 'invalid_code');
    } else {
      const { lat, lng } = body;
      if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) throw new HttpError(400, 'invalid_input');
      const distance = Math.round(logic.distanceMetres(lat, lng, industry.site.lat, industry.site.lng));
      if (distance > industry.site.radiusM) throw new HttpError(400, 'outside_site', 'You are not at the work site', { distance, radius: industry.site.radiusM });
    }

    const open = recordsOf(worker.id).find((r) => !r.checkOut);
    if (open) {
      if ((now - Date.parse(open.checkIn)) / logic.HOUR_MS < MAX_OPEN_SHIFT_HOURS) throw new HttpError(409, 'already_checked_in');
      // A forgotten check-out: close it at the standard day length and mark it so
      // the worker can see (and dispute) the estimate on their payslip.
      open.checkOut = new Date(Date.parse(open.checkIn) + industry.rules.standardDailyHours * logic.HOUR_MS).toISOString();
      open.autoClosed = true;
    }
    const record = { id: store.nextId('a'), workerId: worker.id, checkIn: new Date(now).toISOString(), checkOut: null, method };
    store.attendance.push(record);
    return reply({ openShift: { checkIn: record.checkIn, method } }, 201);
  });

  route('POST', '/api/me/check-out', 'worker', ({ worker, now }) => {
    const { rules } = INDUSTRIES[worker.industry];
    const open = recordsOf(worker.id).find((r) => !r.checkOut);
    if (!open) throw new HttpError(409, 'not_checked_in');
    open.checkOut = new Date(now).toISOString();
    const day = logic.summarizeDays([open], rules)[0];
    return reply({ shift: { checkIn: open.checkIn, checkOut: open.checkOut, hours: day.hours, overtime: day.overtime } });
  });

  route('GET', '/api/me/payslip', 'worker', ({ worker, query, now }) => {
    const { rules } = INDUSTRIES[worker.industry];
    const month = monthParam(query.get('month') || undefined, logic.monthKey(now));
    const records = recordsOf(worker.id);
    const payslip = logic.computePayslip(worker, records, month, rules);
    const open = records.find((r) => !r.checkOut);
    payslip.inProgress = Boolean(open && logic.monthKey(open.checkIn) === month);
    payslip.rules = { standardDailyHours: rules.standardDailyHours, overtimeMultiplier: rules.overtimeMultiplier };
    return reply(payslip);
  });

  /* ---------- worker: grievances & feedback ---------- */

  route('GET', '/api/me/grievances', 'worker', ({ worker }) =>
    reply({
      grievances: store.grievances
        .filter((g) => g.workerId === worker.id)
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
        .map((g) => grievanceView(g)),
    }));

  route('POST', '/api/grievances', 'worker', ({ worker, body, now }) => {
    if (!allow(`grv:${worker.id}`, 15, 3600000)) throw new HttpError(429, 'rate_limited');
    const industry = INDUSTRIES[worker.industry];
    const category = oneOf(body.category, CATEGORIES, 'category');
    const zone = oneOf(body.zone || 'other', industry.zones, 'zone');
    const text = cleanText(body.text, { min: 5, max: 600, field: 'text' });
    const anonymous = body.anonymous === true;
    const at = new Date(now).toISOString();
    const grievance = {
      id: store.nextId('g'), industry: worker.industry, workerId: anonymous ? null : worker.id, category, text, zone,
      urgency: logic.detectUrgency(text, category), createdAt: at, status: 'submitted',
      history: [{ status: 'submitted', at, note: '' }], trackingCode: anonymous ? newTrackingCode() : null,
    };
    store.grievances.push(grievance);
    return reply({ grievance: grievanceView(grievance), trackingCode: grievance.trackingCode }, 201);
  });

  route('GET', '/api/grievances/track/:code', 'worker', ({ worker, params, ip }) => {
    if (!allow(`track:${ip}`, 30, 600000)) throw new HttpError(429, 'rate_limited');
    const code = params.code.toUpperCase();
    const g = store.grievances.find((x) => x.trackingCode === code && x.industry === worker.industry);
    if (!g) throw new HttpError(404, 'not_found');
    return reply({ grievance: grievanceView(g) });
  });

  route('POST', '/api/feedback', 'worker', ({ worker, body, now }) => {
    const ratings = {};
    for (const q of logic.FEEDBACK_QUESTIONS) ratings[q] = rating(body.ratings?.[q], q);
    const comment = cleanText(body.comment, { max: 400, field: 'comment' });

    // One response per person per week, tracked with a keyed hash that is kept
    // apart from the feedback itself. The entry has no ID, no timestamp and is
    // inserted at a random position, so it cannot be traced back to this worker.
    const token = crypto.createHmac('sha256', config.secret).update(`${worker.id}:${weekKey(now)}`).digest('hex');
    if (store.feedbackSubmitted.has(token)) throw new HttpError(409, 'already_submitted');
    store.feedbackSubmitted.add(token);

    const list = store.feedback[worker.industry];
    list.splice(crypto.randomInt(list.length + 1), 0, { ratings, comment, themes: logic.detectThemes(comment) });
    return reply({ ok: true }, 201);
  });

  /* ---------- worker: skill passport ---------- */

  function passportFor(worker, now) {
    const { rules } = INDUSTRIES[worker.industry];
    return {
      passportId: worker.passportId,
      shareEnabled: Boolean(worker.shareToken),
      shareToken: worker.shareToken,
      employer: INDUSTRIES[worker.industry].employer,
      summary: logic.passportSummary(entriesOf(worker.id), loggedHours(recordsOf(worker.id), rules), now),
    };
  }

  route('GET', '/api/me/passport', 'worker', ({ worker, now }) => reply(passportFor(worker, now)));

  route('POST', '/api/me/passport/entries', 'worker', ({ worker, body, now }) => {
    if (entriesOf(worker.id).length >= 60) throw new HttpError(400, 'limit_reached');
    const kind = oneOf(body.kind, ENTRY_KINDS, 'kind');
    const entry = {
      id: store.nextId('s'), workerId: worker.id, kind,
      title: cleanText(body.title, { min: 2, max: 80, field: 'title' }),
      org: cleanText(body.org, { max: 80, field: 'org' }),
      date: optionalDate(body.date, 'date'),
      startDate: optionalDate(body.startDate, 'startDate'),
      endDate: optionalDate(body.endDate, 'endDate'),
      expiresOn: kind === 'experience' ? null : optionalDate(body.expiresOn, 'expiresOn'),
      notes: cleanText(body.notes, { max: 200, field: 'notes' }),
      status: 'self_reported', verifiedBy: null, verifiedAt: null, source: 'worker',
    };
    if (kind === 'experience') {
      if (!entry.startDate) throw new HttpError(400, 'invalid_date', 'startDate is required for experience');
      if (entry.endDate && entry.endDate < entry.startDate) throw new HttpError(400, 'invalid_date', 'endDate is before startDate');
    } else {
      entry.startDate = null;
      entry.endDate = null;
    }
    store.passport.push(entry);
    return reply({ entry, passport: passportFor(worker, now) }, 201);
  });

  route('DELETE', '/api/me/passport/entries/:id', 'worker', ({ worker, params, now }) => {
    const index = store.passport.findIndex((e) => e.id === params.id && e.workerId === worker.id);
    if (index < 0) throw new HttpError(404, 'not_found');
    if (store.passport[index].status === 'verified') throw new HttpError(403, 'verified_locked');
    store.passport.splice(index, 1);
    return reply({ passport: passportFor(worker, now) });
  });

  route('POST', '/api/me/passport/share', 'worker', ({ worker, body, now }) => {
    if (typeof body.enabled !== 'boolean') throw new HttpError(400, 'invalid_input');
    worker.shareToken = body.enabled ? worker.shareToken || crypto.randomBytes(9).toString('base64url') : null;
    return reply(passportFor(worker, now));
  });

  /* ---------- employer: overview, people, complaints ---------- */

  route('GET', '/api/admin/overview', 'admin', ({ industry, now }) => {
    const today = logic.dateKey(now);
    const month = logic.monthKey(now);
    const rows = workersOf(industry.id).map((w) => analyse(w, now));

    const dayMaps = rows.map((r) => logic.summarizeDays(logic.closeOpenAt(r.records, now), industry.rules));
    const trend = Array.from({ length: 14 }, (_, i) => {
      const date = logic.addDays(today, i - 13);
      return { date, present: dayMaps.filter((days) => days.some((d) => d.date === date)).length };
    });
    const recent = dayMaps.flatMap((days) => days.filter((d) => d.date >= logic.addDays(today, -13)));
    const avgHours = recent.length ? logic.round2(recent.reduce((t, d) => t + d.hours, 0) / recent.length) : 0;
    const overtimeThisMonth = logic.round2(
      dayMaps.flat().filter((d) => d.date.startsWith(month)).reduce((t, d) => t + d.overtime, 0),
    );

    const open = store.grievances.filter((g) => g.industry === industry.id && g.status !== 'resolved');
    const skills = adminSkillLists(industry.id, now);
    const fatigueAlerts = rows
      .filter((r) => r.fatigue.level !== 'ok')
      .sort((a, b) => (a.fatigue.level === 'high' ? 0 : 1) - (b.fatigue.level === 'high' ? 0 : 1))
      .map((r) => ({ workerId: r.worker.id, name: r.worker.name, role: r.worker.role, level: r.fatigue.level, reasons: r.fatigue.reasons }));
    const atRisk = rows
      .filter((r) => r.risk.level !== 'low')
      .sort((a, b) => b.risk.score - a.risk.score)
      .map((r) => ({ workerId: r.worker.id, name: r.worker.name, role: r.worker.role, score: r.risk.score, level: r.risk.level, factors: r.risk.factors }));

    return reply({
      kpis: {
        headcount: rows.length,
        onShift: rows.filter((r) => r.open).length,
        avgHours,
        overtimeThisMonth,
        openComplaints: open.length,
        urgentComplaints: open.filter((g) => g.urgency === 'urgent').length,
        fatigueAlerts: fatigueAlerts.length,
        atRisk: atRisk.filter((r) => r.level === 'high').length,
        expiringCerts: skills.expiring.length,
      },
      trend,
      fatigueAlerts,
      atRisk,
      topComplaints: open
        .sort((a, b) => URGENCY_RANK[a.urgency] - URGENCY_RANK[b.urgency] || a.createdAt.localeCompare(b.createdAt))
        .slice(0, 4)
        .map((g) => grievanceView(g, { forAdmin: true })),
    });
  });

  route('GET', '/api/admin/workers', 'admin', ({ industry, now }) =>
    reply({
      workers: workersOf(industry.id).map((w) => {
        const a = analyse(w, now);
        return {
          ...publicWorker(w), joinedOn: w.joinedOn, onShift: Boolean(a.open), since: a.open ? a.open.checkIn : null,
          weeklyHours: a.fatigue.weeklyHours, fatigue: a.fatigue, risk: a.risk,
        };
      }),
    }));

  route('GET', '/api/admin/grievances', 'admin', ({ industry, query }) => {
    const status = query.get('status');
    const list = store.grievances
      .filter((g) => g.industry === industry.id && (!status || status === 'all' || (status === 'open' ? g.status !== 'resolved' : g.status === status)))
      .sort((a, b) => {
        const resolved = (a.status === 'resolved') - (b.status === 'resolved');
        return resolved || URGENCY_RANK[a.urgency] - URGENCY_RANK[b.urgency] || b.createdAt.localeCompare(a.createdAt);
      });
    return reply({ grievances: list.map((g) => grievanceView(g, { forAdmin: true })) });
  });

  route('PATCH', '/api/admin/grievances/:id', 'admin', ({ industry, params, body, now }) => {
    const g = store.grievances.find((x) => x.id === params.id && x.industry === industry.id);
    if (!g) throw new HttpError(404, 'not_found');
    const status = oneOf(body.status, ['in_review', 'resolved'], 'status');
    // Closing a complaint requires telling the worker what was done.
    const note = cleanText(body.note, { min: status === 'resolved' ? 3 : 0, max: 300, field: 'note' });
    g.status = status;
    g.history.push({ status, at: new Date(now).toISOString(), note });
    return reply({ grievance: grievanceView(g, { forAdmin: true }) });
  });

  route('GET', '/api/admin/feedback', 'admin', ({ industry }) => reply(logic.aggregateFeedback(store.feedback[industry.id])));

  /* ---------- employer: skills, payroll, QR ---------- */

  function adminSkillLists(industryId, now) {
    const ids = new Set(workersOf(industryId).map((w) => w.id));
    const withWorker = (e) => {
      const w = workerById(e.workerId);
      return { ...e, expiry: logic.certStatus(e, now), workerName: w.name, workerRole: w.role };
    };
    const entries = store.passport.filter((e) => ids.has(e.workerId)).map(withWorker);
    return {
      pending: entries.filter((e) => e.status === 'self_reported'),
      expiring: entries.filter((e) => e.expiry === 'expiring' || e.expiry === 'expired').sort((a, b) => a.expiresOn.localeCompare(b.expiresOn)),
    };
  }

  route('GET', '/api/admin/skills', 'admin', ({ industry, now }) => reply(adminSkillLists(industry.id, now)));

  route('POST', '/api/admin/skills/:id/verify', 'admin', ({ industry, params, now }) => {
    const entry = store.passport.find((e) => e.id === params.id);
    const owner = entry && workerById(entry.workerId);
    if (!owner || owner.industry !== industry.id) throw new HttpError(404, 'not_found');
    entry.status = 'verified';
    entry.verifiedBy = industry.employer;
    entry.verifiedAt = logic.dateKey(now);
    return reply({ entry });
  });

  route('POST', '/api/admin/training', 'admin', ({ industry, body, now }) => {
    const owner = workerById(body.workerId);
    if (!owner || owner.industry !== industry.id) throw new HttpError(404, 'not_found');
    const entry = {
      id: store.nextId('s'), workerId: owner.id, kind: oneOf(body.kind || 'training', ['training', 'certification'], 'kind'),
      title: cleanText(body.title, { min: 2, max: 80, field: 'title' }), org: industry.employer,
      date: optionalDate(body.date, 'date') || logic.dateKey(now), startDate: null, endDate: null,
      expiresOn: optionalDate(body.expiresOn, 'expiresOn'), notes: '', status: 'verified',
      verifiedBy: industry.employer, verifiedAt: logic.dateKey(now), source: 'employer',
    };
    store.passport.push(entry);
    return reply({ entry }, 201);
  });

  function payrollRows(industry, month) {
    return workersOf(industry.id).map((w) => {
      const p = logic.computePayslip(w, recordsOf(w.id), month, industry.rules);
      return {
        workerId: w.id, name: w.name, role: w.role, rate: w.hourlyRate, days: p.totals.daysWorked,
        regularHours: p.totals.regularHours, overtimeHours: p.totals.overtimeHours,
        gross: p.gross, deductions: p.totalDeductions, net: p.net,
      };
    });
  }

  route('GET', '/api/admin/payroll', 'admin', ({ industry, query, now }) => {
    const month = monthParam(query.get('month') || undefined, logic.monthKey(now));
    const rows = payrollRows(industry, month);
    const total = (key) => logic.round2(rows.reduce((t, r) => t + r[key], 0));
    return reply({ month, rows, totals: { gross: total('gross'), deductions: total('deductions'), net: total('net'), overtimeHours: total('overtimeHours') } });
  });

  route('GET', '/api/admin/payroll.csv', 'admin', ({ industry, query, now }) => {
    const month = monthParam(query.get('month') || undefined, logic.monthKey(now));
    const header = ['Worker ID', 'Name', 'Role', 'Hourly rate', 'Days worked', 'Regular hours', 'Overtime hours', 'Gross pay', 'Deductions', 'Net pay'];
    const lines = payrollRows(industry, month).map((r) =>
      [r.workerId, r.name, r.role, r.rate, r.days, r.regularHours, r.overtimeHours, r.gross, r.deductions, r.net].map(csvCell).join(','));
    return { raw: [header.join(','), ...lines].join('\n'), type: 'text/csv; charset=utf-8', filename: `payroll-${industry.id}-${month}.csv` };
  });

  route('GET', '/api/admin/site-qr', 'admin', ({ industry }) => {
    const svg = fs.readFileSync(path.join(__dirname, 'qr', `${industry.id}.svg`), 'utf8');
    return reply({ svg, siteName: industry.siteName, code: industry.site.code });
  });

  /* ---------- request plumbing ---------- */

  async function readJson(req) {
    const chunks = [];
    let size = 0;
    for await (const chunk of req) {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) throw new HttpError(413, 'too_large');
      chunks.push(chunk);
    }
    if (!size) return {};
    if (!/^application\/json/i.test(req.headers['content-type'] || '')) throw new HttpError(415, 'json_required');
    try {
      const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('not an object');
      return parsed;
    } catch {
      throw new HttpError(400, 'invalid_json');
    }
  }

  function send(res, status, body, extra = {}) {
    const payload = typeof body === 'string' ? body : JSON.stringify(body);
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      ...extra,
      'Content-Length': Buffer.byteLength(payload),
    });
    res.end(payload);
  }

  async function handleApi(req, res, url, ip) {
    const match = routes
      .map((r) => ({ r, m: r.regex.exec(url.pathname) }))
      .find(({ r, m }) => m && r.method === req.method);
    if (!match) throw new HttpError(404, 'not_found');
    const { r, m } = match;

    const bearer = (req.headers.authorization || '').replace(/^Bearer /, '');
    const now = config.now();
    const session = auth.verify(bearer, now);

    const ctx = { query: url.searchParams, ip, now, params: {} };
    r.keys.forEach((key, i) => { ctx.params[key] = decodeURIComponent(m[i + 1]); });

    if (r.access !== 'public') {
      if (!session || session.role !== r.access) throw new HttpError(401, 'unauthorized');
      if (r.access === 'worker') {
        ctx.worker = workerById(session.workerId);
        if (!ctx.worker || ctx.worker.industry !== session.industry) throw new HttpError(401, 'unauthorized');
      } else {
        ctx.industry = INDUSTRIES[session.industry];
      }
    }

    if (!allow(`api:${ip}`, req.method === 'GET' ? 600 : 120, 60000)) throw new HttpError(429, 'rate_limited');
    ctx.body = req.method === 'GET' || req.method === 'HEAD' ? {} : await readJson(req);

    const result = await r.handler(ctx);
    if (result.raw !== undefined) {
      res.writeHead(200, {
        'Content-Type': result.type, 'Cache-Control': 'no-store',
        'Content-Disposition': `attachment; filename="${result.filename}"`,
      });
      res.end(result.raw);
      return;
    }
    send(res, result.status, result.data);
  }

  return async function handler(req, res) {
    for (const [key, value] of Object.entries(SECURITY_HEADERS)) res.setHeader(key, value);
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').split(',')[0].trim();
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname === '/healthz' || url.pathname.startsWith('/api/')) {
        await handleApi(req, res, url, ip);
      } else if (!(await serveStatic(req, res, url.pathname))) {
        throw new HttpError(404, 'not_found');
      }
    } catch (err) {
      if (res.headersSent) return;
      if (err instanceof HttpError) {
        send(res, err.status, { error: err.code, message: err.message, ...(err.details || {}) });
      } else {
        console.error(err);
        send(res, 500, { error: 'server_error' });
      }
    }
  };
}

module.exports = { createApp };
