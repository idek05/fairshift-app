'use strict';
/**
 * FairShift rules engine.
 * Everything here is a pure function (no I/O, no clock access) so it can be
 * unit-tested and reused by both the worker and employer views.
 * All calendar logic is done in Indian Standard Time (IST, UTC+05:30).
 */

const IST_OFFSET_MS = 330 * 60 * 1000;
const HOUR_MS = 3600000;

const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
const sumBy = (items, pick) => items.reduce((total, item) => total + pick(item), 0);

/** YYYY-MM-DD for an instant, in IST. */
function dateKey(ts) {
  return new Date(new Date(ts).getTime() + IST_OFFSET_MS).toISOString().slice(0, 10);
}
const monthKey = (ts) => dateKey(ts).slice(0, 7);

function addDays(key, n) {
  const d = new Date(`${key}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

/** Epoch milliseconds of 00:00 IST on the given date key. */
function istMidnight(key) {
  return Date.parse(`${key}T00:00:00Z`) - IST_OFFSET_MS;
}

/** 0 = Sunday … 6 = Saturday for a date key. */
function weekday(key) {
  return new Date(`${key}T00:00:00Z`).getUTCDay();
}

const hoursBetween = (a, b) => Math.max(0, (new Date(b) - new Date(a)) / HOUR_MS);

/* ------------------------------------------------------------------ */
/* Attendance                                                          */
/* ------------------------------------------------------------------ */

/** Great-circle distance in metres between two coordinates. */
function distanceMetres(lat1, lng1, lat2, lng2) {
  const rad = (deg) => (deg * Math.PI) / 180;
  const dLat = rad(lat2 - lat1);
  const dLng = rad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/**
 * Close any still-open record at `nowTs` so live views can include the shift
 * in progress. Does not mutate the input.
 */
function closeOpenAt(records, nowTs) {
  return records.map((r) => (r.checkOut ? r : { ...r, checkOut: new Date(nowTs).toISOString(), live: true }));
}

/**
 * Group completed records into one summary per IST calendar day.
 * A shift belongs to the day it started on, so night shifts are not split.
 */
function summarizeDays(records, rules) {
  const byDay = new Map();
  for (const r of records) {
    if (!r.checkOut) continue;
    const key = dateKey(r.checkIn);
    const day = byDay.get(key) || { date: key, hours: 0, checkIn: r.checkIn, checkOut: r.checkOut, method: r.method, autoClosed: false, live: false };
    day.hours += hoursBetween(r.checkIn, r.checkOut);
    if (r.checkIn < day.checkIn) day.checkIn = r.checkIn;
    if (r.checkOut > day.checkOut) day.checkOut = r.checkOut;
    day.autoClosed = day.autoClosed || Boolean(r.autoClosed);
    day.live = day.live || Boolean(r.live);
    byDay.set(key, day);
  }
  return [...byDay.values()]
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((d) => {
      const hours = round2(d.hours);
      return {
        ...d,
        hours,
        regular: round2(Math.min(hours, rules.standardDailyHours)),
        overtime: round2(Math.max(0, hours - rules.standardDailyHours)),
      };
    });
}

/* ------------------------------------------------------------------ */
/* Payslip                                                             */
/* ------------------------------------------------------------------ */

/**
 * Build a fully itemised payslip for one worker and month (YYYY-MM).
 * Every line carries the numbers it was computed from, so the UI can explain
 * "why this amount" in the worker's own language.
 */
function computePayslip(worker, records, month, rules) {
  const days = summarizeDays(records, rules).filter((d) => d.date.startsWith(month));
  const regularHours = round2(sumBy(days, (d) => d.regular));
  const overtimeHours = round2(sumBy(days, (d) => d.overtime));
  const rate = worker.hourlyRate;

  const regularPay = round2(regularHours * rate);
  const overtimePay = round2(overtimeHours * rate * rules.overtimeMultiplier);
  const gross = round2(regularPay + overtimePay);

  const pf = round2(regularPay * rules.pfRate);
  const esi = gross > 0 && gross <= rules.esiCeiling ? round2(gross * rules.esiRate) : 0;
  const advance = round2(Math.max(0, Math.min(worker.advanceMonthly || 0, gross - pf - esi)));
  const net = round2(gross - pf - esi - advance);

  const earnings = [
    { code: 'regular', hours: regularHours, rate, amount: regularPay },
    { code: 'overtime', hours: overtimeHours, rate, multiplier: rules.overtimeMultiplier, amount: overtimePay },
  ];
  const deductions = [
    { code: 'pf', base: regularPay, rate: rules.pfRate, amount: pf },
    ...(esi > 0 ? [{ code: 'esi', base: gross, rate: rules.esiRate, amount: esi }] : []),
    ...(advance > 0 ? [{ code: 'advance', amount: advance }] : []),
  ];

  return {
    month,
    workerId: worker.id,
    rate,
    totals: {
      daysWorked: days.length,
      totalHours: round2(regularHours + overtimeHours),
      regularHours,
      overtimeHours,
    },
    earnings,
    deductions,
    gross,
    totalDeductions: round2(pf + esi + advance),
    net,
    days,
  };
}

/* ------------------------------------------------------------------ */
/* Fatigue                                                             */
/* ------------------------------------------------------------------ */

/**
 * Look at the last 7 IST days (including today) and report rest-related risks.
 * Each reason is a machine-readable code so the UI can translate it.
 */
function assessFatigue(records, rules, nowTs) {
  const live = closeOpenAt(records, nowTs);
  const today = dateKey(nowTs);
  const windowStart = addDays(today, -6);
  const allDays = summarizeDays(live, rules);
  const week = allDays.filter((d) => d.date >= windowStart && d.date <= today);

  const weeklyHours = round2(sumBy(week, (d) => d.hours));
  const longDays = week.filter((d) => d.hours > rules.longDayHours).length;

  const worked = new Set(allDays.map((d) => d.date));
  let cursor = worked.has(today) ? today : addDays(today, -1);
  let consecutiveDays = 0;
  while (worked.has(cursor)) {
    consecutiveDays += 1;
    cursor = addDays(cursor, -1);
  }

  const sorted = [...live].sort((a, b) => a.checkIn.localeCompare(b.checkIn));
  let shortRests = 0;
  let minRestHours = null;
  for (let i = 1; i < sorted.length; i += 1) {
    const prev = sorted[i - 1];
    const next = sorted[i];
    if (dateKey(prev.checkIn) === dateKey(next.checkIn) || dateKey(next.checkIn) < windowStart) continue;
    const gap = hoursBetween(prev.checkOut, next.checkIn);
    if (gap < rules.minRestHours) {
      shortRests += 1;
      minRestHours = minRestHours === null ? gap : Math.min(minRestHours, gap);
    }
  }

  const reasons = [];
  // Over the weekly limit is a warning; well over (15%+) is a high-severity alert.
  if (weeklyHours > rules.weeklyLimit * 1.15) reasons.push({ code: 'weekly_hours', level: 'high', value: weeklyHours, limit: rules.weeklyLimit });
  else if (weeklyHours > rules.weeklyLimit) reasons.push({ code: 'weekly_hours', level: 'warn', value: weeklyHours, limit: rules.weeklyLimit });

  if (consecutiveDays > rules.maxConsecutiveDays) reasons.push({ code: 'consecutive_days', level: 'high', value: consecutiveDays, limit: rules.maxConsecutiveDays });
  else if (consecutiveDays === rules.maxConsecutiveDays) reasons.push({ code: 'consecutive_days', level: 'warn', value: consecutiveDays, limit: rules.maxConsecutiveDays });

  if (longDays >= 4) reasons.push({ code: 'long_days', level: 'high', value: longDays, limit: rules.longDayHours });
  else if (longDays >= 2) reasons.push({ code: 'long_days', level: 'warn', value: longDays, limit: rules.longDayHours });

  if (shortRests >= 3) reasons.push({ code: 'short_rest', level: 'high', value: shortRests, limit: rules.minRestHours, minRestHours: round2(minRestHours) });
  else if (shortRests >= 1) reasons.push({ code: 'short_rest', level: 'warn', value: shortRests, limit: rules.minRestHours, minRestHours: round2(minRestHours) });

  const level = reasons.some((r) => r.level === 'high') ? 'high' : reasons.length ? 'warn' : 'ok';
  return { level, weeklyHours, consecutiveDays, longDays, shortRests, reasons };
}

/* ------------------------------------------------------------------ */
/* Attrition (likely-to-leave) risk                                    */
/* ------------------------------------------------------------------ */

const STALE_GRIEVANCE_DAYS = 7;

/**
 * Transparent 0-100 score. There is no black box: each factor adds a fixed,
 * capped number of points and is returned so a manager can see *why*.
 * It is meant to trigger support (rest, a conversation, fixing a complaint),
 * not discipline.
 */
function assessAttritionRisk({ worker, records, grievances, fatigue, rules, nowTs }) {
  const today = dateKey(nowTs);
  const days = summarizeDays(closeOpenAt(records, nowTs), rules);
  const factors = [];
  const add = (code, points, value) => {
    if (points > 0) factors.push({ code, points: Math.round(points), value });
  };

  // 1. Absence over the last 30 days (a 6-day week is ~25.7 expected days).
  const from30 = addDays(today, -29);
  const workedDays = days.filter((d) => d.date >= from30).length;
  const attendanceRate = Math.min(1, workedDays / ((30 * 6) / 7));
  add('absence', Math.min(30, (1 - attendanceRate) * 60), round2(attendanceRate * 100));

  // 2. Average weekly overtime over the last 4 weeks.
  const from28 = addDays(today, -27);
  const weeklyOvertime = sumBy(days.filter((d) => d.date >= from28), (d) => d.overtime) / 4;
  add('overtime', Math.min(20, weeklyOvertime * 2), round2(weeklyOvertime));

  // 3. Fatigue flags this week.
  add('fatigue', fatigue.level === 'high' ? 15 : fatigue.level === 'warn' ? 7 : 0, fatigue.level);

  // 4. Complaints that are still open (extra weight when ignored for a week+).
  const open = grievances.filter((g) => g.workerId === worker.id && g.status !== 'resolved');
  const stale = open.filter((g) => (nowTs - Date.parse(g.createdAt)) / 86400000 > STALE_GRIEVANCE_DAYS).length;
  add('open_complaints', Math.min(30, open.length * 10 + stale * 10), open.length);

  // 5. New joiners leave more often.
  const tenureMonths = (nowTs - Date.parse(worker.joinedOn)) / (30.44 * 86400000);
  add('tenure', tenureMonths < 6 ? 10 : tenureMonths < 12 ? 5 : 0, round2(tenureMonths));

  factors.sort((a, b) => b.points - a.points);
  const score = Math.min(100, sumBy(factors, (f) => f.points));
  const level = score >= 45 ? 'high' : score >= 30 ? 'medium' : 'low';
  return { score, level, factors };
}

/* ------------------------------------------------------------------ */
/* Grievances                                                          */
/* ------------------------------------------------------------------ */

const URGENT_WORDS = [
  'fall', 'fell', 'scaffold', 'electric', 'shock', 'fire', 'gas', 'injur', 'bleed', 'collapse', 'crane',
  'chemical', 'smoke', 'unsafe', 'exposed wire', 'harness', 'no helmet', 'leak', 'fume', 'explosion',
  'ஆபத்து', 'காயம்', 'மின்சார', 'விழ', 'आग', 'करंट', 'गिर', 'चोट', 'खतरा', 'धुआं',
];

/** Escalate anything that looks like a physical danger so it is seen first. */
function detectUrgency(text, category) {
  const lower = String(text).toLowerCase();
  const dangerous = URGENT_WORDS.some((w) => lower.includes(w));
  if (dangerous && category === 'safety') return 'urgent';
  if (dangerous || category === 'safety') return 'high';
  return 'normal';
}

/* ------------------------------------------------------------------ */
/* Anonymous feedback                                                  */
/* ------------------------------------------------------------------ */

const FEEDBACK_QUESTIONS = ['manager', 'safety', 'pay', 'workplace'];
const MIN_FEEDBACK_RESPONSES = 5;

const THEME_KEYWORDS = {
  pay: ['salary', 'pay', 'wage', 'overtime', 'deduct', 'bonus', 'சம்பளம்', 'வேதனம்', 'वेतन', 'पगार', 'ओवरटाइम'],
  safety: ['safe', 'helmet', 'harness', 'scaffold', 'fire', 'injur', 'accident', 'danger', 'electric', 'பாதுகாப்பு', 'सुरक्षा', 'हेलमेट'],
  manager: ['manager', 'supervisor', 'foreman', 'boss', 'shout', 'warden', 'mistreat', 'மேலாளர்', 'மேற்பார்வையாளர்', 'सुपरवाइज़र', 'मैनेजर', 'डांट'],
  facilities: ['toilet', 'water', 'canteen', 'food', 'restroom', 'rest room', 'shade', 'hostel', 'குடிநீர்', 'கழிப்பறை', 'पानी', 'शौचालय', 'खाना'],
  schedule: ['shift', 'night duty', 'leave', 'holiday', 'weekend', 'schedule', 'rest day', 'விடுமுறை', 'ஷிப்ட்', 'छुट्टी', 'शिफ्ट'],
  respect: ['respect', 'dignity', 'insult', 'bias', 'discriminat', 'harass', 'மரியாதை', 'सम्मान', 'भेदभाव'],
};

function detectThemes(text) {
  const lower = String(text).toLowerCase();
  return Object.entries(THEME_KEYWORDS)
    .filter(([, words]) => words.some((w) => lower.includes(w)))
    .map(([theme]) => theme);
}

/**
 * Aggregate anonymous feedback. Nothing is shown until enough people have
 * responded, so a tiny team can never be "de-anonymised" by its own numbers.
 * Comments are shuffled and carry no timestamp or ID.
 */
function aggregateFeedback(entries, rng = Math.random) {
  const responses = entries.length;
  if (responses < MIN_FEEDBACK_RESPONSES) return { visible: false, responses, minResponses: MIN_FEEDBACK_RESPONSES };

  const averages = {};
  for (const q of FEEDBACK_QUESTIONS) averages[q] = round2(sumBy(entries, (e) => e.ratings[q]) / responses);

  const themes = {};
  for (const e of entries) for (const t of e.themes) themes[t] = (themes[t] || 0) + 1;

  const comments = entries.filter((e) => e.comment).map((e) => ({ text: e.comment, themes: e.themes }));
  for (let i = comments.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    [comments[i], comments[j]] = [comments[j], comments[i]];
  }
  return { visible: true, responses, minResponses: MIN_FEEDBACK_RESPONSES, averages, themes, comments };
}

/* ------------------------------------------------------------------ */
/* Skill passport                                                      */
/* ------------------------------------------------------------------ */

const EXPIRY_WARNING_DAYS = 60;

/** 'valid' | 'expiring' | 'expired' | 'none' for an entry with an optional expiry date. */
function certStatus(entry, nowTs) {
  if (!entry.expiresOn) return 'none';
  const days = (Date.parse(`${entry.expiresOn}T00:00:00Z`) - istMidnight(dateKey(nowTs))) / 86400000;
  if (days < 0) return 'expired';
  return days <= EXPIRY_WARNING_DAYS ? 'expiring' : 'valid';
}

/** Whole years of experience from "experience" entries (open-ended ones run to today). */
function experienceYears(entries, nowTs) {
  const ms = sumBy(
    entries.filter((e) => e.kind === 'experience' && e.startDate),
    (e) => {
      const end = e.endDate ? Date.parse(e.endDate) : nowTs;
      return Math.max(0, end - Date.parse(e.startDate));
    },
  );
  return round2(ms / (365.25 * 86400000));
}

function passportSummary(entries, loggedHours, nowTs) {
  const withStatus = entries.map((e) => ({ ...e, expiry: certStatus(e, nowTs) }));
  return {
    entries: withStatus,
    counts: {
      certification: entries.filter((e) => e.kind === 'certification').length,
      training: entries.filter((e) => e.kind === 'training').length,
      experience: entries.filter((e) => e.kind === 'experience').length,
      verified: entries.filter((e) => e.status === 'verified').length,
      expiring: withStatus.filter((e) => e.expiry === 'expiring' || e.expiry === 'expired').length,
    },
    experienceYears: experienceYears(entries, nowTs),
    loggedHours: round2(loggedHours),
  };
}

module.exports = {
  round2, dateKey, monthKey, addDays, istMidnight, weekday, hoursBetween, distanceMetres,
  closeOpenAt, summarizeDays, computePayslip, assessFatigue, assessAttritionRisk,
  detectUrgency, detectThemes, aggregateFeedback, certStatus, experienceYears, passportSummary,
  FEEDBACK_QUESTIONS, MIN_FEEDBACK_RESPONSES, HOUR_MS,
};
