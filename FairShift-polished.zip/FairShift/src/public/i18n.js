const LANG_KEY = 'fs.lang';
const supported = ['en', 'ta', 'hi'];
export const getLang = () => { try { const v = localStorage.getItem(LANG_KEY); return supported.includes(v) ? v : 'en'; } catch { return 'en'; } };
export const setLang = (v) => { if (supported.includes(v)) { try { localStorage.setItem(LANG_KEY, v); } catch {} } };
export const locale = () => ({ en: 'en-IN', ta: 'ta-IN', hi: 'hi-IN' }[getLang()] || 'en-IN');
export const t = (key, vars = {}) => {
  const words = {
    'common.loading':'Loading…','common.retry':'Try again','common.error':'Something went wrong',
    'nav.today':'Today','nav.pay':'Pay','nav.speak':'Speak up','nav.passport':'Passport',
    'today.week':'This week','today.std':'Standard: {hours} hours',
    'pp.share.copied':'Link copied','pp.share.copyfail':'Copy the link manually',
  };
  return (words[key] || key).replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? `{${k}}`));
};
export function initLanguageSelect(el, onChange) { if (!el) return; el.value = getLang(); el.addEventListener('change', () => { setLang(el.value); onChange?.(); }); }
export function applyI18n(root) { if (!root) return; root.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); }); }
