'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const path = require('node:path');

const { createApp } = require('../src/app');
const { createStore, INDUSTRIES } = require('../src/data');

const clock = { now: Date.parse('2026-10-27T10:00:00Z') };
const config = {
  demoMode: true, adminPasscode: '', secret: 'test-secret',
  publicDir: path.join(__dirname, '..', 'public'), now: () => clock.now,
};

let server;
let base;

test.before(async () => {
  server = http.createServer(createApp({ store: createStore(clock.now), config }));
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

async function call(method, url, { token, body, raw } = {}) {
  const res = await fetch(base + url, {
    method,
    headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(body || raw ? { 'Content-Type': 'application/json' } : {}) },
    body: raw ?? (body ? JSON.stringify(body) : undefined),
  });
  const text = await res.text();
  let data = text;
  try { data = JSON.parse(text); } catch { /* not JSON (csv, html) */ }
  return { status: res.status, data, headers: res.headers };
}

const login = async (workerId, industry = workerId.startsWith('k') ? 'college' : 'construction') =>
  (await call('POST', '/api/session', { body: { role: 'worker', industry, workerId } })).data.token;
const adminLogin = async (industry = 'construction') =>
  (await call('POST', '/api/session', { body: { role: 'admin', industry } })).data.token;

test('health check and security headers', async () => {
  const res = await call('GET', '/healthz');
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-security-policy'), /default-src 'self'/);
  assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
});

test('public industry list never leaks the site QR code', async () => {
  const res = await call('GET', '/api/industries');
  assert.equal(res.data.industries.length, 2);
  assert.doesNotMatch(JSON.stringify(res.data), /FS-SITE/);
});

test('protected routes require the right role', async () => {
  assert.equal((await call('GET', '/api/me')).status, 401);
  assert.equal((await call('GET', '/api/admin/overview')).status, 401);
  const worker = await login('c1');
  assert.equal((await call('GET', '/api/admin/overview', { token: worker })).status, 401);
  const admin = await adminLogin();
  assert.equal((await call('GET', '/api/me', { token: admin })).status, 401);
  assert.equal((await call('GET', '/api/me', { token: `${worker}x` })).status, 401);
});

test('a worker cannot log in to the other industry', async () => {
  const res = await call('POST', '/api/session', { body: { role: 'worker', industry: 'college', workerId: 'c1' } });
  assert.equal(res.status, 404);
});

test('admin passcode is enforced when configured', async () => {
  const guarded = http.createServer(createApp({ store: createStore(clock.now), config: { ...config, adminPasscode: 'letmein-123' } }));
  await new Promise((resolve) => guarded.listen(0, '127.0.0.1', resolve));
  const url = `http://127.0.0.1:${guarded.address().port}/api/session`;
  const attempt = (passcode) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ role: 'admin', industry: 'college', passcode }) });
  assert.equal((await attempt('wrong')).status, 401);
  assert.equal((await attempt('letmein-123')).status, 200);
  guarded.close();
});

test('check-in: wrong code, right code, duplicate, then check-out with hours', async () => {
  const token = await login('c6');
  const today = await call('GET', '/api/me/today', { token });
  if (today.data.openShift) await call('POST', '/api/me/check-out', { token });

  const code = (await call('GET', '/api/me', { token })).data.demoSiteCode;
  assert.equal(code, INDUSTRIES.construction.site.code);

  assert.equal((await call('POST', '/api/me/check-in', { token, body: { method: 'qr', code: 'WRONG' } })).data.error, 'invalid_code');
  assert.equal((await call('POST', '/api/me/check-in', { token, body: { method: 'qr', code } })).status, 201);
  assert.equal((await call('POST', '/api/me/check-in', { token, body: { method: 'qr', code } })).status, 409);

  clock.now += 9.5 * 3600000;
  const out = await call('POST', '/api/me/check-out', { token });
  assert.equal(out.status, 200);
  assert.equal(out.data.shift.hours, 9.5);
  assert.equal(out.data.shift.overtime, 1.5);
  assert.equal((await call('POST', '/api/me/check-out', { token })).status, 409);
});

test('location check-in enforces the geofence', async () => {
  const token = await login('c2');
  const open = (await call('GET', '/api/me/today', { token })).data.openShift;
  if (open) await call('POST', '/api/me/check-out', { token });
  const far = await call('POST', '/api/me/check-in', { token, body: { method: 'geo', lat: 12.9, lng: 80.0 } });
  assert.equal(far.status, 400);
  assert.equal(far.data.error, 'outside_site');
  assert.ok(far.data.distance > far.data.radius);
  const { lat, lng } = INDUSTRIES.construction.site;
  assert.equal((await call('POST', '/api/me/check-in', { token, body: { method: 'geo', lat, lng } })).status, 201);
  assert.equal((await call('POST', '/api/me/check-in', { token, body: { method: 'geo', lat: 'x', lng: 1 } })).status, 400);
});

test('payslip adds up and rejects bad months', async () => {
  const token = await login('c1');
  const res = await call('GET', '/api/me/payslip?month=2026-10', { token });
  assert.equal(res.status, 200);
  const p = res.data;
  const earned = p.earnings.reduce((t, e) => t + e.amount, 0);
  const deducted = p.deductions.reduce((t, d) => t + d.amount, 0);
  assert.ok(Math.abs(earned - p.gross) < 0.01);
  assert.ok(Math.abs(p.gross - deducted - p.net) < 0.01);
  assert.ok(p.totals.overtimeHours > 0, 'seeded mason works overtime');
  assert.ok(p.days.length > 0);
  assert.equal((await call('GET', '/api/me/payslip?month=2026-13', { token })).status, 400);
  assert.equal((await call('GET', '/api/me/payslip?month=abc', { token })).status, 400);
});

test('a worker only ever sees their own data', async () => {
  const a = await call('GET', '/api/me/payslip?month=2026-10', { token: await login('c1') });
  const b = await call('GET', '/api/me/payslip?month=2026-10', { token: await login('c2') });
  assert.notEqual(a.data.workerId, b.data.workerId);
  assert.notEqual(a.data.gross, b.data.gross);
});

test('grievances: urgency, tracking, status history and resolution rules', async () => {
  const token = await login('c3');
  const created = await call('POST', '/api/grievances', { token, body: { category: 'safety', zone: 'scaffolding', text: 'Scaffold plank is broken and someone may fall' } });
  assert.equal(created.status, 201);
  assert.equal(created.data.grievance.urgency, 'urgent');
  assert.equal(created.data.trackingCode, null);

  const mine = await call('GET', '/api/me/grievances', { token });
  assert.ok(mine.data.grievances.some((g) => g.id === created.data.grievance.id));

  const admin = await adminLogin();
  const id = created.data.grievance.id;
  assert.equal((await call('PATCH', `/api/admin/grievances/${id}`, { token: admin, body: { status: 'resolved', note: '' } })).status, 400);
  assert.equal((await call('PATCH', `/api/admin/grievances/${id}`, { token: admin, body: { status: 'in_review', note: 'Inspecting now' } })).status, 200);
  const done = await call('PATCH', `/api/admin/grievances/${id}`, { token: admin, body: { status: 'resolved', note: 'Plank replaced and checked' } });
  assert.equal(done.data.grievance.status, 'resolved');

  const after = await call('GET', '/api/me/grievances', { token });
  const view = after.data.grievances.find((g) => g.id === id);
  assert.deepEqual(view.history.map((h) => h.status), ['submitted', 'in_review', 'resolved']);
  assert.equal(view.history[2].note, 'Plank replaced and checked');
});

test('anonymous reports hide the worker but can be tracked by code', async () => {
  const token = await login('c4');
  const res = await call('POST', '/api/grievances', { token, body: { category: 'conduct', zone: 'gate', text: 'Supervisor abuses workers at the gate', anonymous: true } });
  assert.equal(res.status, 201);
  assert.match(res.data.trackingCode, /^FS-[A-Z0-9]{5}$/);

  // Not in the worker's own list (it is not linked to them)...
  const mine = await call('GET', '/api/me/grievances', { token });
  assert.ok(!mine.data.grievances.some((g) => g.id === res.data.grievance.id));
  // ...but trackable with the code, and the employer sees no name.
  const tracked = await call('GET', `/api/grievances/track/${res.data.trackingCode.toLowerCase()}`, { token });
  assert.equal(tracked.status, 200);
  const admin = await adminLogin();
  const list = await call('GET', '/api/admin/grievances?status=open', { token: admin });
  const row = list.data.grievances.find((g) => g.id === res.data.grievance.id);
  assert.equal(row.workerName, null);
  assert.equal(row.anonymous, true);
  assert.equal((await call('GET', '/api/grievances/track/FS-ZZZZZ', { token })).status, 404);
});

test('grievance input is validated', async () => {
  const token = await login('c3');
  const bad = (body) => call('POST', '/api/grievances', { token, body });
  assert.equal((await bad({ category: 'nope', text: 'hello there' })).status, 400);
  assert.equal((await bad({ category: 'pay', text: 'hi' })).status, 400);
  assert.equal((await bad({ category: 'pay', text: 'x'.repeat(601) })).status, 400);
  assert.equal((await bad({ category: 'pay', text: 'valid text here', zone: 'moon' })).status, 400);
});

test('anonymous feedback: one per week, no identity stored, aggregate only', async () => {
  const token = await login('c8');
  const ratings = { manager: 4, safety: 2, pay: 3, workplace: 5 };
  assert.equal((await call('POST', '/api/feedback', { token, body: { ratings: { ...ratings, pay: 9 }, comment: '' } })).status, 400);
  assert.equal((await call('POST', '/api/feedback', { token, body: { ratings, comment: 'Water is finished by afternoon' } })).status, 201);
  assert.equal((await call('POST', '/api/feedback', { token, body: { ratings, comment: '' } })).data.error, 'already_submitted');

  const admin = await adminLogin();
  const agg = (await call('GET', '/api/admin/feedback', { token: admin })).data;
  assert.equal(agg.visible, true);
  assert.equal(agg.responses, 15);
  assert.ok(agg.averages.safety > 0);
  assert.ok(agg.themes.facilities >= 1);
  assert.doesNotMatch(JSON.stringify(agg), /workerId|c8|createdAt/);
});

test('skill passport: add, verify lock, share, public view, revoke', async () => {
  const token = await login('c2');
  const add = await call('POST', '/api/me/passport/entries', { token, body: { kind: 'certification', title: 'Fire Safety Basics', org: 'Fire Dept', date: '2026-01-10', expiresOn: '2027-01-10' } });
  assert.equal(add.status, 201);
  assert.equal(add.data.entry.status, 'self_reported');
  assert.equal(add.data.passport.summary.counts.certification, 1);

  const exp = await call('POST', '/api/me/passport/entries', { token, body: { kind: 'experience', title: 'Helper', org: 'Site X', startDate: '2024-01-01', endDate: '2023-01-01' } });
  assert.equal(exp.status, 400);
  assert.equal((await call('POST', '/api/me/passport/entries', { token, body: { kind: 'experience', title: 'Helper', org: 'Site X' } })).status, 400);
  assert.equal((await call('POST', '/api/me/passport/entries', { token, body: { kind: 'certification', title: 'Bad', date: '2026-02-31' } })).status, 400);

  const admin = await adminLogin();
  const pending = await call('GET', '/api/admin/skills', { token: admin });
  assert.ok(pending.data.pending.some((e) => e.id === add.data.entry.id));
  await call('POST', `/api/admin/skills/${add.data.entry.id}/verify`, { token: admin });
  const locked = await call('DELETE', `/api/me/passport/entries/${add.data.entry.id}`, { token });
  assert.equal(locked.status, 403);

  const mine = await call('GET', '/api/me/passport', { token });
  assert.equal(mine.data.shareEnabled, false);
  assert.equal((await call('GET', '/api/passport/not-a-real-token')).status, 404);
  const shared = await call('POST', '/api/me/passport/share', { token, body: { enabled: true } });
  assert.ok(shared.data.shareToken.length >= 10);
  const pub = await call('GET', `/api/passport/${shared.data.shareToken}`);
  assert.equal(pub.status, 200);
  assert.equal(pub.data.name, 'Lakshmi P.');
  assert.doesNotMatch(JSON.stringify(pub.data), /hourlyRate|advance/);
  await call('POST', '/api/me/passport/share', { token, body: { enabled: false } });
  assert.equal((await call('GET', `/api/passport/${shared.data.shareToken}`)).status, 404);
});

test('a worker cannot delete or verify someone else\'s entries', async () => {
  const other = await login('c2');
  const entryOfC3 = (await call('GET', '/api/me/passport', { token: await login('c3') })).data.summary.entries.find((e) => e.status === 'self_reported');
  assert.equal((await call('DELETE', `/api/me/passport/entries/${entryOfC3.id}`, { token: other })).status, 404);
  const collegeAdmin = await adminLogin('college');
  assert.equal((await call('POST', `/api/admin/skills/${entryOfC3.id}/verify`, { token: collegeAdmin })).status, 404);
});

test('the seeded demo passport link works for judges', async () => {
  const res = await call('GET', '/api/passport/demo-passport');
  assert.equal(res.status, 200);
  assert.ok(res.data.summary.counts.verified >= 3);
  assert.ok(res.data.summary.experienceYears > 5);
});

test('employer overview surfaces fatigue, risk, complaints and certificates', async () => {
  const admin = await adminLogin();
  const { data, status } = await call('GET', '/api/admin/overview', { token: admin });
  assert.equal(status, 200);
  assert.equal(data.kpis.headcount, 8);
  assert.equal(data.trend.length, 14);
  assert.ok(data.fatigueAlerts.some((a) => a.workerId === 'c1' && a.level === 'high'), 'overworked mason is flagged');
  assert.ok(data.fatigueAlerts.some((a) => a.workerId === 'c5'), 'back-to-back crane operator is flagged');
  assert.ok(data.atRisk.length > 0);
  assert.ok(data.kpis.openComplaints >= 3);
  assert.ok(data.kpis.expiringCerts >= 1);
  assert.equal(data.topComplaints[0].urgency, 'urgent');
});

test('employer data is scoped to their own industry', async () => {
  const college = await adminLogin('college');
  const { data } = await call('GET', '/api/admin/workers', { token: college });
  assert.equal(data.workers.length, 8);
  assert.ok(data.workers.every((w) => w.id.startsWith('k')));
  assert.equal((await call('POST', '/api/admin/training', { token: college, body: { workerId: 'c1', title: 'Hacking' } })).status, 404);
});

test('employer can add verified training to a worker passport', async () => {
  const admin = await adminLogin();
  const res = await call('POST', '/api/admin/training', { token: admin, body: { workerId: 'c6', title: 'Bar Bending Schedule Reading', expiresOn: '2028-01-01' } });
  assert.equal(res.status, 201);
  assert.equal(res.data.entry.status, 'verified');
  const passport = await call('GET', '/api/me/passport', { token: await login('c6') });
  assert.ok(passport.data.summary.entries.some((e) => e.title === 'Bar Bending Schedule Reading' && e.source === 'employer'));
});

test('payroll JSON and CSV export', async () => {
  const admin = await adminLogin();
  const json = await call('GET', '/api/admin/payroll?month=2026-10', { token: admin });
  assert.equal(json.data.rows.length, 8);
  assert.ok(json.data.totals.net > 0);
  const csv = await call('GET', '/api/admin/payroll.csv?month=2026-10', { token: admin });
  assert.match(csv.headers.get('content-type'), /text\/csv/);
  assert.match(csv.headers.get('content-disposition'), /payroll-construction-2026-10\.csv/);
  assert.equal(csv.data.split('\n').length, 9);
  assert.equal((await call('GET', '/api/admin/payroll?month=bad', { token: admin })).status, 400);
});

test('admin can fetch the printable site QR', async () => {
  const { data } = await call('GET', '/api/admin/site-qr', { token: await adminLogin('college') });
  assert.match(data.svg, /^<svg/);
  assert.equal(data.code, INDUSTRIES.college.site.code);
});

test('malformed requests are rejected safely', async () => {
  const token = await login('c1');
  assert.equal((await call('POST', '/api/feedback', { token, raw: '{not json' })).status, 400);
  assert.equal((await call('POST', '/api/feedback', { token, raw: '[1,2]' })).status, 400);
  assert.equal((await call('POST', '/api/grievances', { token, raw: JSON.stringify({ text: 'x'.repeat(40000) }) })).status, 413);
  assert.equal((await call('GET', '/api/nope', { token })).status, 404);
});

test('static files are served, compressed, and cannot escape the public folder', async () => {
  const home = await fetch(`${base}/`);
  assert.equal(home.status, 200);
  const etag = home.headers.get('etag');
  assert.equal((await fetch(`${base}/`, { headers: { 'If-None-Match': etag } })).status, 304);
  assert.equal((await fetch(`${base}/%2e%2e/server.js`)).status, 404);
  assert.equal((await fetch(`${base}/..%2fserver.js`)).status, 404);
  assert.equal((await fetch(`${base}/%00`)).status, 404);
});
