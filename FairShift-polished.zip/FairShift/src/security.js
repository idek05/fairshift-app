'use strict';
/**
 * Security helpers with no third-party dependencies:
 *  - HMAC-signed, expiring session tokens (role-scoped)
 *  - a small fixed-window rate limiter
 *  - strict input validation / sanitising
 */

const crypto = require('node:crypto');

/* ---------- sessions ---------- */

const b64url = (buf) => Buffer.from(buf).toString('base64url');

function createAuth(secret, ttlMs = 12 * 3600 * 1000) {
  const sign = (body) => crypto.createHmac('sha256', secret).update(body).digest('base64url');
  return {
    issue(payload, now = Date.now()) {
      const body = b64url(JSON.stringify({ ...payload, exp: now + ttlMs }));
      return `${body}.${sign(body)}`;
    },
    verify(token, now = Date.now()) {
      if (typeof token !== 'string' || token.length > 600) return null;
      const [body, sig] = token.split('.');
      if (!body || !sig) return null;
      const expected = Buffer.from(sign(body));
      const given = Buffer.from(sig);
      if (expected.length !== given.length || !crypto.timingSafeEqual(expected, given)) return null;
      try {
        const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
        return payload.exp > now ? payload : null;
      } catch {
        return null;
      }
    },
  };
}

/** Constant-time string comparison (for the optional admin passcode). */
function safeEqual(a, b) {
  const x = crypto.createHash('sha256').update(String(a)).digest();
  const y = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
}

/* ---------- rate limiting ---------- */

function createRateLimiter() {
  const hits = new Map();
  const timer = setInterval(() => {
    const now = Date.now();
    for (const [key, entry] of hits) if (entry.resetAt <= now) hits.delete(key);
  }, 60000);
  timer.unref();

  return function allow(key, limit, windowMs, now = Date.now()) {
    const entry = hits.get(key);
    if (!entry || entry.resetAt <= now) {
      hits.set(key, { count: 1, resetAt: now + windowMs });
      return true;
    }
    entry.count += 1;
    return entry.count <= limit;
  };
}

/* ---------- validation ---------- */

class HttpError extends Error {
  constructor(status, code, message, details) {
    super(message || code);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

/** Trim, drop control characters, and enforce a length cap. */
function cleanText(value, { max = 500, min = 0, field = 'text' } = {}) {
  if (value === undefined || value === null) value = '';
  if (typeof value !== 'string') throw new HttpError(400, 'invalid_input', `${field} must be text`);
  // eslint-disable-next-line no-control-regex
  const text = value.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim();
  if (text.length < min) throw new HttpError(400, 'too_short', `${field} is too short`);
  if (text.length > max) throw new HttpError(400, 'too_long', `${field} is too long`);
  return text;
}

function oneOf(value, allowed, field = 'value') {
  if (!allowed.includes(value)) throw new HttpError(400, 'invalid_input', `${field} is not allowed`);
  return value;
}

/** Real calendar date in YYYY-MM-DD form, or null when empty. */
function optionalDate(value, field = 'date') {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new HttpError(400, 'invalid_date', `${field} must be YYYY-MM-DD`);
  const d = new Date(`${value}T00:00:00Z`);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== value) throw new HttpError(400, 'invalid_date', `${field} is not a real date`);
  return value;
}

function monthParam(value, fallback) {
  if (value === undefined || value === '') return fallback;
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(value)) throw new HttpError(400, 'invalid_month', 'month must be YYYY-MM');
  return value;
}

function rating(value, field) {
  if (!Number.isInteger(value) || value < 1 || value > 5) throw new HttpError(400, 'invalid_input', `${field} must be 1-5`);
  return value;
}

/** Neutralise spreadsheet formula injection when exporting CSV. */
function csvCell(value) {
  let s = String(value ?? '');
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

module.exports = {
  createAuth, safeEqual, createRateLimiter, HttpError, cleanText, oneOf, optionalDate, monthParam, rating, csvCell,
};
