'use strict';
/**
 * Industry profiles + demo seed data.
 *
 * FairShift is industry-agnostic: everything that differs between a
 * construction site and a college (wording, overtime rules, work areas, QR
 * site code, geofence) lives in an industry profile below. Adding a hospital or
 * a factory means adding one more profile - no code changes.
 *
 * Seed data is generated deterministically from the clock passed to
 * createStore(), so the demo always looks "live" and tests are repeatable.
 * All names are fictional.
 */

const {
  round2, dateKey, addDays, istMidnight, weekday, detectThemes, detectUrgency, HOUR_MS,
} = require('./logic');

const INDUSTRIES = {
  construction: {
    id: 'construction',
    employer: 'BuildRight Constructions',
    label: 'Construction site',
    siteName: 'Metro Depot Site, Block A',
    supervisorLabel: 'Foreman',
    site: { code: 'FS-SITE-BLD01', lat: 13.085, lng: 80.2101, radiusM: 250 },
    zones: ['scaffolding', 'excavation', 'electrical', 'crane', 'canteen', 'gate', 'other'],
    skillSuggestions: ['Working at Height', 'Scaffolding Safety', 'Electrical Safety', 'Welding 6G', 'First Aid', 'Fire Safety', 'Crane Operation', 'Bar Bending'],
    rules: {
      standardDailyHours: 8, overtimeMultiplier: 2, weeklyLimit: 48, longDayHours: 10,
      minRestHours: 10, maxConsecutiveDays: 6, pfRate: 0.12, esiRate: 0.0075, esiCeiling: 21000,
    },
  },
  college: {
    id: 'college',
    employer: 'Sunrise College of Engineering',
    label: 'College campus',
    siteName: 'Main Campus',
    supervisorLabel: 'Department head',
    site: { code: 'FS-SITE-CLG01', lat: 12.9716, lng: 80.0443, radiusM: 400 },
    zones: ['lab', 'hostel', 'library', 'classroom', 'canteen', 'gate', 'other'],
    skillSuggestions: ['Lab Safety', 'First Aid', 'Fire Safety', 'Computer Skills', 'Library Science', 'Electrical Maintenance', 'Hostel Management'],
    rules: {
      standardDailyHours: 8, overtimeMultiplier: 1.5, weeklyLimit: 48, longDayHours: 10,
      minRestHours: 10, maxConsecutiveDays: 6, pfRate: 0.12, esiRate: 0.0075, esiCeiling: 21000,
    },
  },
};

/** Fields safe to send to any visitor (never the site QR code). */
function publicIndustry(i) {
  return {
    id: i.id, employer: i.employer, label: i.label, siteName: i.siteName,
    supervisorLabel: i.supervisorLabel, zones: i.zones, skillSuggestions: i.skillSuggestions,
    rules: i.rules, site: { lat: i.site.lat, lng: i.site.lng, radiusM: i.site.radiusM },
  };
}

/* ---------- deterministic pseudo-random numbers ---------- */

function seededRandom(str) {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i += 1) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  let a = h >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ---------- people ---------- */

// `months` = how long ago they joined. `p` tunes the generated attendance.
const WORKERS = [
  { id: 'c1', industry: 'construction', name: 'Murugan S.', role: 'Mason', hourlyRate: 105, advanceMonthly: 500, months: 38, p: { attend: 0.95, start: 7.5, hours: 8.3, ot: 0.35, otExtra: 2, streak: 8, longHours: 10.2 } },
  { id: 'c2', industry: 'construction', name: 'Lakshmi P.', role: 'Helper', hourlyRate: 70, advanceMonthly: 0, months: 14, p: { attend: 0.96, start: 7.5, hours: 8, ot: 0.1, otExtra: 1.5 } },
  { id: 'c3', industry: 'construction', name: 'Arun Kumar', role: 'Electrician', hourlyRate: 125, advanceMonthly: 0, months: 26, p: { attend: 0.94, start: 8, hours: 8.2, ot: 0.2, otExtra: 2 } },
  { id: 'c4', industry: 'construction', name: 'Selvi R.', role: 'Painter', hourlyRate: 85, advanceMonthly: 800, months: 4, p: { attend: 0.6, start: 8, hours: 8, ot: 0.05, otExtra: 1 } },
  { id: 'c5', industry: 'construction', name: 'Rajesh Yadav', role: 'Crane Operator', hourlyRate: 150, advanceMonthly: 0, months: 20, p: { attend: 0.95, start: 8, hours: 8.5, ot: 0.15, otExtra: 2, backToBack: true } },
  { id: 'c6', industry: 'construction', name: 'Kavitha M.', role: 'Bar Bender', hourlyRate: 95, advanceMonthly: 0, months: 8, p: { attend: 0.93, start: 7.5, hours: 8, ot: 0.15, otExtra: 1.5 } },
  { id: 'c7', industry: 'construction', name: 'Imran Sheikh', role: 'Welder', hourlyRate: 115, advanceMonthly: 0, months: 11, p: { attend: 0.93, start: 8, hours: 8.4, ot: 0.55, otExtra: 2.5 } },
  { id: 'c8', industry: 'construction', name: 'Ganesan T.', role: 'Carpenter', hourlyRate: 100, advanceMonthly: 600, months: 62, p: { attend: 0.95, start: 8, hours: 8, ot: 0.12, otExtra: 1.5 } },
  { id: 'k1', industry: 'college', name: 'Meena R.', role: 'Lab Assistant', hourlyRate: 90, advanceMonthly: 0, months: 36, p: { attend: 0.96, start: 8.5, hours: 8, ot: 0.12, otExtra: 1.5 } },
  { id: 'k2', industry: 'college', name: 'Suresh Babu', role: 'Hostel Warden', hourlyRate: 100, advanceMonthly: 0, months: 72, p: { attend: 0.95, start: 8, hours: 8.5, ot: 0.2, otExtra: 2, backToBack: true } },
  { id: 'k3', industry: 'college', name: 'Anitha K.', role: 'Hostel Matron', hourlyRate: 85, advanceMonthly: 500, months: 18, p: { attend: 0.94, start: 7, hours: 8.2, ot: 0.4, otExtra: 2.5 } },
  { id: 'k4', industry: 'college', name: 'Faizal A.', role: 'Security Guard', hourlyRate: 80, advanceMonthly: 0, months: 24, p: { attend: 0.97, start: 6, hours: 11.5, ot: 0, otExtra: 0, streak: 7, longHours: 11.5 } },
  { id: 'k5', industry: 'college', name: 'Priya D.', role: 'Librarian', hourlyRate: 110, advanceMonthly: 0, months: 50, p: { attend: 0.96, start: 9, hours: 8, ot: 0.05, otExtra: 1 } },
  { id: 'k6', industry: 'college', name: 'Karthik V.', role: 'Admin Clerk', hourlyRate: 95, advanceMonthly: 0, months: 5, p: { attend: 0.62, start: 9, hours: 8, ot: 0.05, otExtra: 1 } },
  { id: 'k7', industry: 'college', name: 'Vimala S.', role: 'Housekeeping Lead', hourlyRate: 75, advanceMonthly: 400, months: 84, p: { attend: 0.95, start: 7, hours: 8, ot: 0.1, otExtra: 1.5 } },
  { id: 'k8', industry: 'college', name: 'Mohan P.', role: 'Maintenance Electrician', hourlyRate: 120, advanceMonthly: 0, months: 36, p: { attend: 0.94, start: 8.5, hours: 8.2, ot: 0.3, otExtra: 2 } },
];

/* ---------- generated attendance ---------- */

function buildAttendance(worker, now, nextId) {
  const rng = seededRandom(`${worker.id}:attendance`);
  const p = worker.p;
  const today = dateKey(now);
  const records = [];
  const push = (key, startHour, hours) => {
    const checkIn = istMidnight(key) + startHour * HOUR_MS;
    records.push({
      id: nextId('a'),
      workerId: worker.id,
      checkIn: new Date(checkIn).toISOString(),
      checkOut: new Date(checkIn + hours * HOUR_MS).toISOString(),
      method: rng() < 0.7 ? 'qr' : 'geo',
    });
  };

  for (let d = 45; d >= 1; d -= 1) {
    const key = addDays(today, -d);
    if (p.backToBack && d <= 4) {
      // Late shift, then an early shift next morning: only ~7.5 h of rest.
      if (d % 2 === 0) push(key, 14, 8.5);
      else push(key, 6, 8.5);
      continue;
    }
    const forced = d <= (p.streak || 0);
    if (!forced && weekday(key) === 0) continue;
    if (!forced && rng() > p.attend) continue;
    let hours = p.hours + (rng() - 0.5) * 0.6;
    if (forced && p.longHours) hours = p.longHours + (rng() - 0.5) * 0.6;
    else if (rng() < p.ot) hours += p.otExtra * (0.5 + rng());
    push(key, p.start + (rng() - 0.5), round2(hours));
  }

  // Today: most people are on shift right now (open record, no check-out yet).
  const onShift = p.streak || rng() < 0.8;
  if (onShift) {
    const since = now - (1 + rng() * 4) * HOUR_MS;
    records.push({ id: nextId('a'), workerId: worker.id, checkIn: new Date(since).toISOString(), checkOut: null, method: 'qr' });
  }
  return records;
}

/* ---------- grievances ---------- */

function buildGrievances(now, nextId) {
  const ago = (days) => new Date(now - days * 86400000).toISOString();
  const make = (industry, workerId, category, text, zone, daysAgo, steps, extra = {}) => {
    const history = steps.map(([status, d, note]) => ({ status, at: ago(d), note }));
    return {
      id: nextId('g'), industry, workerId, category, text, zone,
      urgency: detectUrgency(text, category), createdAt: ago(daysAgo),
      status: history[history.length - 1].status, history, trackingCode: null, ...extra,
    };
  };
  return [
    make('construction', 'c1', 'pay', 'Overtime for 12 and 13 October was not added to my payslip.', 'other', 9, [['submitted', 9, ''], ['in_review', 8, 'Checking attendance logs with the site office.']]),
    make('construction', 'c7', 'safety', 'Harness anchor point is missing on level 4 scaffolding. We are working without it.', 'scaffolding', 1, [['submitted', 1, '']]),
    make('construction', null, 'safety', 'Exposed wire hanging near the canteen entrance.', 'canteen', 3, [['submitted', 3, ''], ['in_review', 2, 'Electrician assigned to inspect today.']], { trackingCode: 'FS-7K3QX' }),
    make('construction', 'c2', 'facilities', 'Drinking water tank is empty by afternoon.', 'canteen', 12, [['submitted', 12, ''], ['in_review', 11, 'Vendor contacted.'], ['resolved', 8, 'Second tank installed and refilled twice a day.']]),
    make('construction', 'c5', 'schedule', 'I was given a night shift and then a morning shift the next day with no rest.', 'crane', 4, [['submitted', 4, '']]),
    make('college', 'k2', 'schedule', 'Hostel night duty followed by morning duty again. Please fix the roster.', 'hostel', 6, [['submitted', 6, ''], ['in_review', 5, 'Roster under review with the warden office.']]),
    make('college', 'k1', 'safety', 'Fume hood in Chemistry lab 2 is not working. Fumes are building up.', 'lab', 1, [['submitted', 1, '']]),
    make('college', 'k6', 'pay', 'Last month salary came 8 days late.', 'other', 20, [['submitted', 20, ''], ['resolved', 17, 'Accounts confirmed the delay and set a fixed payment date.']]),
    make('college', null, 'conduct', 'A department head shouts at staff in front of students.', 'classroom', 5, [['submitted', 5, '']], { trackingCode: 'FS-4P9WD' }),
    make('college', 'k4', 'facilities', 'Security guards at the main gate have no rest room.', 'gate', 10, [['submitted', 10, ''], ['in_review', 7, 'Space being identified near the gate.']]),
  ];
}

/* ---------- anonymous feedback ---------- */

const FEEDBACK_COMMENTS = {
  construction: [
    'The foreman shouts at us in front of everyone. Please train supervisors to speak with respect.',
    'Helmets are given but a harness is missing on the higher floors.',
    'Overtime is not shown anywhere. We only find out at the end of the month.',
    'Drinking water is finished by afternoon. We need more water points.',
    'Night shift followed by morning shift is too tiring.',
    'Salary is on time, which is good. Please show how it is calculated.',
    'Toilets near block B are not cleaned.',
  ],
  college: [
    'Some department heads shout at staff in front of students.',
    'Hostel night duty and next-morning duty back to back is exhausting.',
    'Salary comes late some months. Please tell us in advance.',
    'The fume hood in block C has not worked for weeks. It is not safe.',
    'Canteen food quality is good, thank you.',
    'Security staff have no rest room at the gate.',
    'We get no weekly holiday when there are events.',
  ],
};

function buildFeedback(industry) {
  const rng = seededRandom(`${industry}:feedback`);
  const base = industry === 'construction' ? { manager: 3.2, safety: 2.8, pay: 3.1, workplace: 3.3 } : { manager: 3.4, safety: 3.3, pay: 3.0, workplace: 3.5 };
  const rate = (mean) => Math.max(1, Math.min(5, Math.round(mean + (rng() - 0.5) * 3)));
  const comments = FEEDBACK_COMMENTS[industry];
  return Array.from({ length: 14 }, (_, i) => {
    const comment = i % 3 === 2 ? '' : comments[i % comments.length];
    return {
      ratings: { manager: rate(base.manager), safety: rate(base.safety), pay: rate(base.pay), workplace: rate(base.workplace) },
      comment,
      themes: detectThemes(comment),
    };
  });
}

/* ---------- skill passport ---------- */

function buildPassport(now, nextId) {
  const day = (offset) => addDays(dateKey(now), offset);
  const entries = [];
  const add = (workerId, kind, title, org, opts = {}) => {
    entries.push({
      id: nextId('s'), workerId, kind, title, org, date: opts.date || null, startDate: opts.startDate || null,
      endDate: opts.endDate || null, expiresOn: opts.expiresOn || null, notes: opts.notes || '',
      status: opts.verified ? 'verified' : 'self_reported',
      verifiedBy: opts.verified ? opts.verified : null, verifiedAt: opts.verified ? day(-30) : null,
      source: opts.source || 'worker',
    });
  };
  const BR = INDUSTRIES.construction.employer;
  const SC = INDUSTRIES.college.employer;

  add('c3', 'experience', 'Electrician', 'ElectroWorks, Chennai', { startDate: '2019-03-01', endDate: '2023-02-28' });
  add('c3', 'experience', 'Electrician', BR, { startDate: day(-26 * 30), verified: BR, source: 'employer' });
  add('c3', 'certification', 'ITI Electrician (NCVT)', 'Government ITI, Guindy', { date: '2018-06-30', verified: BR });
  add('c3', 'certification', 'Electrical Safety & Lockout/Tagout', BR, { date: day(-240), expiresOn: day(120), verified: BR, source: 'employer' });
  add('c3', 'training', 'Working at Height', BR, { date: day(-200), expiresOn: day(430), verified: BR, source: 'employer' });
  add('c3', 'certification', 'First Aid', 'St John Ambulance', { date: day(-700), expiresOn: day(25) });

  add('c1', 'experience', 'Mason', 'Local contractors, Madurai', { startDate: '2008-01-01', endDate: '2022-08-31' });
  add('c1', 'training', 'Scaffolding Safety', BR, { date: day(-300), expiresOn: day(65), verified: BR, source: 'employer' });
  add('c7', 'certification', 'Welding 6G', 'NSDC Skill Centre', { date: '2020-11-15' });
  add('c7', 'training', 'Hot Work Safety', BR, { date: day(-150), expiresOn: day(215), verified: BR, source: 'employer' });
  add('c8', 'certification', 'First Aid', 'Red Cross', { date: day(-700), expiresOn: day(20), verified: BR });
  add('c8', 'training', 'Fire Safety', BR, { date: day(-120), expiresOn: day(245), verified: BR, source: 'employer' });

  add('k1', 'certification', 'Lab Safety & Chemical Handling', SC, { date: day(-180), expiresOn: day(185), verified: SC, source: 'employer' });
  add('k1', 'experience', 'Lab Assistant', SC, { startDate: day(-36 * 30), verified: SC, source: 'employer' });
  add('k5', 'certification', 'Bachelor of Library & Information Science', 'Madras University', { date: '2012-05-20', verified: SC });
  add('k5', 'training', 'Digital Library Tools', SC, { date: day(-400), verified: SC, source: 'employer' });
  add('k5', 'experience', 'Librarian', 'City Public Library', { startDate: '2013-06-01', endDate: '2018-04-30' });
  add('k2', 'training', 'Fire Safety', SC, { date: day(-420), expiresOn: day(-10), verified: SC, source: 'employer' });
  add('k2', 'certification', 'First Aid', 'St John Ambulance', { date: day(-300), expiresOn: day(40) });
  return entries;
}

/* ---------- store ---------- */

const TOKEN_ALPHABET = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';

/** Build a complete in-memory store, seeded relative to `now` (epoch ms). */
function createStore(now = Date.now()) {
  let counter = 0;
  const nextId = (prefix) => `${prefix}${(counter += 1).toString(36)}`;

  const workers = WORKERS.map(({ p: _attendanceProfile, months, ...w }, i) => ({
    ...w,
    joinedOn: addDays(dateKey(now), -Math.round(months * 30.44)),
    passportId: `FSP-${(204117 + i * 137).toString()}`,
    shareToken: null,
  }));
  workers.find((w) => w.id === 'c3').shareToken = 'demo-passport';
  workers.find((w) => w.id === 'k5').shareToken = 'demo-passport-college';

  const attendance = WORKERS.flatMap((w) => buildAttendance(w, now, nextId));
  return {
    nextId,
    workers,
    attendance,
    grievances: buildGrievances(now, nextId),
    feedback: { construction: buildFeedback('construction'), college: buildFeedback('college') },
    feedbackSubmitted: new Set(),
    passport: buildPassport(now, nextId),
  };
}

module.exports = { INDUSTRIES, publicIndustry, createStore, seededRandom, TOKEN_ALPHABET };
