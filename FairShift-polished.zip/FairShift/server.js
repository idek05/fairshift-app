'use strict';
const http = require('node:http');
const path = require('node:path');
const { createApp } = require('./src/app');
const { createStore } = require('./src/data');
const port = Number(process.env.PORT || 8080);
const config = {
  secret: process.env.FAIRSHIFT_SECRET || 'replace-this-demo-secret-before-production-please',
  adminPasscode: process.env.ADMIN_PASSCODE || '',
  demoMode: process.env.DEMO_MODE !== 'false',
  publicDir: path.join(__dirname, 'src', 'public'),
  now: () => Date.now(),
};
const app = createApp({ store: createStore(), config });
http.createServer(app).listen(port, '0.0.0.0', () => console.log(`FairShift listening on ${port}`));
